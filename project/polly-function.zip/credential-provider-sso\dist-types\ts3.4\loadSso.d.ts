import { GetRoleCredentialsCommand, SSOClient } from "@aws-sdk/client-sso";
export { GetRoleCredentialsCommand, SSOClient };
export {
  SSOClientConfig,
  GetRoleCredentialsCommandOutput,
} from "@aws-sdk/client-sso";
