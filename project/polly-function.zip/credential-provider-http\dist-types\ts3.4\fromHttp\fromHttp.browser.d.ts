import { AwsCredentialIdentityProvider } from "@smithy/types";
import { FromHttpOptions } from "./fromHttpTypes";
export declare const fromHttp: (
  options?: FromHttpOptions
) => AwsCredentialIdentityProvider;
