import {
  HttpRequest as __HttpRequest,
  HttpResponse as __HttpResponse,
} from "@smithy/protocol-http";
import {
  SdkStreamSerdeContext as __SdkStreamSerdeContext,
  SerdeContext as __SerdeContext,
} from "@smithy/types";
import {
  DeleteLexiconCommandInput,
  DeleteLexiconCommandOutput,
} from "../commands/DeleteLexiconCommand";
import {
  DescribeVoicesCommandInput,
  DescribeVoicesCommandOutput,
} from "../commands/DescribeVoicesCommand";
import {
  GetLexiconCommandInput,
  GetLexiconCommandOutput,
} from "../commands/GetLexiconCommand";
import {
  GetSpeechSynthesisTaskCommandInput,
  GetSpeechSynthesisTaskCommandOutput,
} from "../commands/GetSpeechSynthesisTaskCommand";
import {
  ListLexiconsCommandInput,
  ListLexiconsCommandOutput,
} from "../commands/ListLexiconsCommand";
import {
  ListSpeechSynthesisTasksCommandInput,
  ListSpeechSynthesisTasksCommandOutput,
} from "../commands/ListSpeechSynthesisTasksCommand";
import {
  PutLexiconCommandInput,
  PutLexiconCommandOutput,
} from "../commands/PutLexiconCommand";
import {
  StartSpeechSynthesisTaskCommandInput,
  StartSpeechSynthesisTaskCommandOutput,
} from "../commands/StartSpeechSynthesisTaskCommand";
import {
  SynthesizeSpeechCommandInput,
  SynthesizeSpeechCommandOutput,
} from "../commands/SynthesizeSpeechCommand";
export declare const se_DeleteLexiconCommand: (
  input: DeleteLexiconCommandInput,
  context: __SerdeContext
) => Promise<__HttpRequest>;
export declare const se_DescribeVoicesCommand: (
  input: DescribeVoicesCommandInput,
  context: __SerdeContext
) => Promise<__HttpRequest>;
export declare const se_GetLexiconCommand: (
  input: GetLexiconCommandInput,
  context: __SerdeContext
) => Promise<__HttpRequest>;
export declare const se_GetSpeechSynthesisTaskCommand: (
  input: GetSpeechSynthesisTaskCommandInput,
  context: __SerdeContext
) => Promise<__HttpRequest>;
export declare const se_ListLexiconsCommand: (
  input: ListLexiconsCommandInput,
  context: __SerdeContext
) => Promise<__HttpRequest>;
export declare const se_ListSpeechSynthesisTasksCommand: (
  input: ListSpeechSynthesisTasksCommandInput,
  context: __SerdeContext
) => Promise<__HttpRequest>;
export declare const se_PutLexiconCommand: (
  input: PutLexiconCommandInput,
  context: __SerdeContext
) => Promise<__HttpRequest>;
export declare const se_StartSpeechSynthesisTaskCommand: (
  input: StartSpeechSynthesisTaskCommandInput,
  context: __SerdeContext
) => Promise<__HttpRequest>;
export declare const se_SynthesizeSpeechCommand: (
  input: SynthesizeSpeechCommandInput,
  context: __SerdeContext
) => Promise<__HttpRequest>;
export declare const de_DeleteLexiconCommand: (
  output: __HttpResponse,
  context: __SerdeContext
) => Promise<DeleteLexiconCommandOutput>;
export declare const de_DescribeVoicesCommand: (
  output: __HttpResponse,
  context: __SerdeContext
) => Promise<DescribeVoicesCommandOutput>;
export declare const de_GetLexiconCommand: (
  output: __HttpResponse,
  context: __SerdeContext
) => Promise<GetLexiconCommandOutput>;
export declare const de_GetSpeechSynthesisTaskCommand: (
  output: __HttpResponse,
  context: __SerdeContext
) => Promise<GetSpeechSynthesisTaskCommandOutput>;
export declare const de_ListLexiconsCommand: (
  output: __HttpResponse,
  context: __SerdeContext
) => Promise<ListLexiconsCommandOutput>;
export declare const de_ListSpeechSynthesisTasksCommand: (
  output: __HttpResponse,
  context: __SerdeContext
) => Promise<ListSpeechSynthesisTasksCommandOutput>;
export declare const de_PutLexiconCommand: (
  output: __HttpResponse,
  context: __SerdeContext
) => Promise<PutLexiconCommandOutput>;
export declare const de_StartSpeechSynthesisTaskCommand: (
  output: __HttpResponse,
  context: __SerdeContext
) => Promise<StartSpeechSynthesisTaskCommandOutput>;
export declare const de_SynthesizeSpeechCommand: (
  output: __HttpResponse,
  context: __SerdeContext & __SdkStreamSerdeContext
) => Promise<SynthesizeSpeechCommandOutput>;
