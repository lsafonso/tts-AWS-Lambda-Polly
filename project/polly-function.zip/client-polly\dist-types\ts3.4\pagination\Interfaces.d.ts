import { PaginationConfiguration } from "@smithy/types";
import { PollyClient } from "../PollyClient";
export interface PollyPaginationConfiguration extends PaginationConfiguration {
  client: PollyClient;
}
