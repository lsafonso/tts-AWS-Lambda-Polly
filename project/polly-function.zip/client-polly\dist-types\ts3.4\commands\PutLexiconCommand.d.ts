import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { PutLexiconInput, PutLexiconOutput } from "../models/models_0";
import {
  PollyClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../PollyClient";
export { __MetadataBearer };
export { $Command };
export interface PutLexiconCommandInput extends PutLexiconInput {}
export interface PutLexiconCommandOutput
  extends PutLexiconOutput,
    __MetadataBearer {}
declare const PutLexiconCommand_base: {
  new (
    input: PutLexiconCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    PutLexiconCommandInput,
    PutLexiconCommandOutput,
    PollyClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    input: PutLexiconCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    PutLexiconCommandInput,
    PutLexiconCommandOutput,
    PollyClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class PutLexiconCommand extends PutLexiconCommand_base {
  protected static __types: {
    api: {
      input: PutLexiconInput;
      output: {};
    };
    sdk: {
      input: PutLexiconCommandInput;
      output: PutLexiconCommandOutput;
    };
  };
}
