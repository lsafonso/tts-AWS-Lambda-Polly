export declare const getBearerTokenEnvKey: (signingName: string) => string;
