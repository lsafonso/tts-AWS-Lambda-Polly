import { createPaginator } from "@smithy/core";
import { ListSpeechSynthesisTasksCommand, } from "../commands/ListSpeechSynthesisTasksCommand";
import { PollyClient } from "../PollyClient";
export const paginateListSpeechSynthesisTasks = createPaginator(PollyClient, ListSpeechSynthesisTasksCommand, "NextToken", "NextToken", "MaxResults");
