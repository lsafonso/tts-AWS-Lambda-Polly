import { createAggregatedClient } from "@smithy/smithy-client";
import { DeleteLexiconCommand, } from "./commands/DeleteLexiconCommand";
import { DescribeVoicesCommand, } from "./commands/DescribeVoicesCommand";
import { GetLexiconCommand } from "./commands/GetLexiconCommand";
import { GetSpeechSynthesisTaskCommand, } from "./commands/GetSpeechSynthesisTaskCommand";
import { ListLexiconsCommand, } from "./commands/ListLexiconsCommand";
import { ListSpeechSynthesisTasksCommand, } from "./commands/ListSpeechSynthesisTasksCommand";
import { PutLexiconCommand } from "./commands/PutLexiconCommand";
import { StartSpeechSynthesisTaskCommand, } from "./commands/StartSpeechSynthesisTaskCommand";
import { SynthesizeSpeechCommand, } from "./commands/SynthesizeSpeechCommand";
import { PollyClient } from "./PollyClient";
const commands = {
    DeleteLexiconCommand,
    DescribeVoicesCommand,
    GetLexiconCommand,
    GetSpeechSynthesisTaskCommand,
    ListLexiconsCommand,
    ListSpeechSynthesisTasksCommand,
    PutLexiconCommand,
    StartSpeechSynthesisTaskCommand,
    SynthesizeSpeechCommand,
};
export class Polly extends PollyClient {
}
createAggregatedClient(commands, Polly);
