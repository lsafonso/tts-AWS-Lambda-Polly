import {
  HostHeaderInputConfig,
  HostHeaderResolvedConfig,
} from "@aws-sdk/middleware-host-header";
import {
  UserAgentInputConfig,
  UserAgentResolvedConfig,
} from "@aws-sdk/middleware-user-agent";
import {
  RegionInputConfig,
  RegionResolvedConfig,
} from "@smithy/config-resolver";
import {
  EndpointInputConfig,
  EndpointResolvedConfig,
} from "@smithy/middleware-endpoint";
import {
  RetryInputConfig,
  RetryResolvedConfig,
} from "@smithy/middleware-retry";
import { HttpHandlerUserInput as __HttpHandlerUserInput } from "@smithy/protocol-http";
import {
  Client as __Client,
  DefaultsMode as __DefaultsMode,
  SmithyConfiguration as __SmithyConfiguration,
  SmithyResolvedConfiguration as __SmithyResolvedConfiguration,
} from "@smithy/smithy-client";
import {
  AwsCredentialIdentityProvider,
  BodyLengthCalculator as __BodyLengthCalculator,
  CheckOptionalClientConfig as __CheckOptionalClientConfig,
  ChecksumConstructor as __ChecksumConstructor,
  Decoder as __Decoder,
  Encoder as __Encoder,
  HashConstructor as __HashConstructor,
  HttpHandlerOptions as __HttpHandlerOptions,
  Logger as __Logger,
  Provider as __Provider,
  Provider,
  SdkStreamMixinInjector as __SdkStreamMixinInjector,
  StreamCollector as __StreamCollector,
  UrlParser as __UrlParser,
  UserAgent as __UserAgent,
} from "@smithy/types";
import {
  HttpAuthSchemeInputConfig,
  HttpAuthSchemeResolvedConfig,
} from "./auth/httpAuthSchemeProvider";
import {
  DeleteLexiconCommandInput,
  DeleteLexiconCommandOutput,
} from "./commands/DeleteLexiconCommand";
import {
  DescribeVoicesCommandInput,
  DescribeVoicesCommandOutput,
} from "./commands/DescribeVoicesCommand";
import {
  GetLexiconCommandInput,
  GetLexiconCommandOutput,
} from "./commands/GetLexiconCommand";
import {
  GetSpeechSynthesisTaskCommandInput,
  GetSpeechSynthesisTaskCommandOutput,
} from "./commands/GetSpeechSynthesisTaskCommand";
import {
  ListLexiconsCommandInput,
  ListLexiconsCommandOutput,
} from "./commands/ListLexiconsCommand";
import {
  ListSpeechSynthesisTasksCommandInput,
  ListSpeechSynthesisTasksCommandOutput,
} from "./commands/ListSpeechSynthesisTasksCommand";
import {
  PutLexiconCommandInput,
  PutLexiconCommandOutput,
} from "./commands/PutLexiconCommand";
import {
  StartSpeechSynthesisTaskCommandInput,
  StartSpeechSynthesisTaskCommandOutput,
} from "./commands/StartSpeechSynthesisTaskCommand";
import {
  SynthesizeSpeechCommandInput,
  SynthesizeSpeechCommandOutput,
} from "./commands/SynthesizeSpeechCommand";
import {
  ClientInputEndpointParameters,
  ClientResolvedEndpointParameters,
  EndpointParameters,
} from "./endpoint/EndpointParameters";
import { RuntimeExtension, RuntimeExtensionsConfig } from "./runtimeExtensions";
export { __Client };
export type ServiceInputTypes =
  | DeleteLexiconCommandInput
  | DescribeVoicesCommandInput
  | GetLexiconCommandInput
  | GetSpeechSynthesisTaskCommandInput
  | ListLexiconsCommandInput
  | ListSpeechSynthesisTasksCommandInput
  | PutLexiconCommandInput
  | StartSpeechSynthesisTaskCommandInput
  | SynthesizeSpeechCommandInput;
export type ServiceOutputTypes =
  | DeleteLexiconCommandOutput
  | DescribeVoicesCommandOutput
  | GetLexiconCommandOutput
  | GetSpeechSynthesisTaskCommandOutput
  | ListLexiconsCommandOutput
  | ListSpeechSynthesisTasksCommandOutput
  | PutLexiconCommandOutput
  | StartSpeechSynthesisTaskCommandOutput
  | SynthesizeSpeechCommandOutput;
export interface ClientDefaults
  extends Partial<__SmithyConfiguration<__HttpHandlerOptions>> {
  requestHandler?: __HttpHandlerUserInput;
  sha256?: __ChecksumConstructor | __HashConstructor;
  urlParser?: __UrlParser;
  bodyLengthChecker?: __BodyLengthCalculator;
  streamCollector?: __StreamCollector;
  base64Decoder?: __Decoder;
  base64Encoder?: __Encoder;
  utf8Decoder?: __Decoder;
  utf8Encoder?: __Encoder;
  runtime?: string;
  disableHostPrefix?: boolean;
  serviceId?: string;
  useDualstackEndpoint?: boolean | __Provider<boolean>;
  useFipsEndpoint?: boolean | __Provider<boolean>;
  region?: string | __Provider<string>;
  profile?: string;
  defaultUserAgentProvider?: Provider<__UserAgent>;
  credentialDefaultProvider?: (input: any) => AwsCredentialIdentityProvider;
  maxAttempts?: number | __Provider<number>;
  retryMode?: string | __Provider<string>;
  logger?: __Logger;
  extensions?: RuntimeExtension[];
  defaultsMode?: __DefaultsMode | __Provider<__DefaultsMode>;
  sdkStreamMixin?: __SdkStreamMixinInjector;
}
export type PollyClientConfigType = Partial<
  __SmithyConfiguration<__HttpHandlerOptions>
> &
  ClientDefaults &
  UserAgentInputConfig &
  RetryInputConfig &
  RegionInputConfig &
  HostHeaderInputConfig &
  EndpointInputConfig<EndpointParameters> &
  HttpAuthSchemeInputConfig &
  ClientInputEndpointParameters;
export interface PollyClientConfig extends PollyClientConfigType {}
export type PollyClientResolvedConfigType =
  __SmithyResolvedConfiguration<__HttpHandlerOptions> &
    Required<ClientDefaults> &
    RuntimeExtensionsConfig &
    UserAgentResolvedConfig &
    RetryResolvedConfig &
    RegionResolvedConfig &
    HostHeaderResolvedConfig &
    EndpointResolvedConfig<EndpointParameters> &
    HttpAuthSchemeResolvedConfig &
    ClientResolvedEndpointParameters;
export interface PollyClientResolvedConfig
  extends PollyClientResolvedConfigType {}
export declare class PollyClient extends __Client<
  __HttpHandlerOptions,
  ServiceInputTypes,
  ServiceOutputTypes,
  PollyClientResolvedConfig
> {
  readonly config: PollyClientResolvedConfig;
  constructor(
    ...[configuration]: __CheckOptionalClientConfig<PollyClientConfig>
  );
  destroy(): void;
}
