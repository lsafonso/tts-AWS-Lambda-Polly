"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.ts
var index_exports = {};
__export(index_exports, {
  DeleteLexiconCommand: () => DeleteLexiconCommand,
  DescribeVoicesCommand: () => DescribeVoicesCommand,
  Engine: () => Engine,
  EngineNotSupportedException: () => EngineNotSupportedException,
  Gender: () => Gender,
  GetLexiconCommand: () => GetLexiconCommand,
  GetLexiconOutputFilterSensitiveLog: () => GetLexiconOutputFilterSensitiveLog,
  GetSpeechSynthesisTaskCommand: () => GetSpeechSynthesisTaskCommand,
  InvalidLexiconException: () => InvalidLexiconException,
  InvalidNextTokenException: () => InvalidNextTokenException,
  InvalidS3BucketException: () => InvalidS3BucketException,
  InvalidS3KeyException: () => InvalidS3KeyException,
  InvalidSampleRateException: () => InvalidSampleRateException,
  InvalidSnsTopicArnException: () => InvalidSnsTopicArnException,
  InvalidSsmlException: () => InvalidSsmlException,
  InvalidTaskIdException: () => InvalidTaskIdException,
  LanguageCode: () => LanguageCode,
  LanguageNotSupportedException: () => LanguageNotSupportedException,
  LexiconFilterSensitiveLog: () => LexiconFilterSensitiveLog,
  LexiconNotFoundException: () => LexiconNotFoundException,
  LexiconSizeExceededException: () => LexiconSizeExceededException,
  ListLexiconsCommand: () => ListLexiconsCommand,
  ListSpeechSynthesisTasksCommand: () => ListSpeechSynthesisTasksCommand,
  MarksNotSupportedForFormatException: () => MarksNotSupportedForFormatException,
  MaxLexemeLengthExceededException: () => MaxLexemeLengthExceededException,
  MaxLexiconsNumberExceededException: () => MaxLexiconsNumberExceededException,
  OutputFormat: () => OutputFormat,
  Polly: () => Polly,
  PollyClient: () => PollyClient,
  PollyServiceException: () => PollyServiceException,
  PutLexiconCommand: () => PutLexiconCommand,
  PutLexiconInputFilterSensitiveLog: () => PutLexiconInputFilterSensitiveLog,
  ServiceFailureException: () => ServiceFailureException,
  SpeechMarkType: () => SpeechMarkType,
  SsmlMarksNotSupportedForTextTypeException: () => SsmlMarksNotSupportedForTextTypeException,
  StartSpeechSynthesisTaskCommand: () => StartSpeechSynthesisTaskCommand,
  SynthesisTaskNotFoundException: () => SynthesisTaskNotFoundException,
  SynthesizeSpeechCommand: () => SynthesizeSpeechCommand,
  SynthesizeSpeechOutputFilterSensitiveLog: () => SynthesizeSpeechOutputFilterSensitiveLog,
  TaskStatus: () => TaskStatus,
  TextLengthExceededException: () => TextLengthExceededException,
  TextType: () => TextType,
  UnsupportedPlsAlphabetException: () => UnsupportedPlsAlphabetException,
  UnsupportedPlsLanguageException: () => UnsupportedPlsLanguageException,
  VoiceId: () => VoiceId,
  __Client: () => import_smithy_client.Client,
  paginateListSpeechSynthesisTasks: () => paginateListSpeechSynthesisTasks
});
module.exports = __toCommonJS(index_exports);

// src/PollyClient.ts
var import_middleware_host_header = require("@aws-sdk/middleware-host-header");
var import_middleware_logger = require("@aws-sdk/middleware-logger");
var import_middleware_recursion_detection = require("@aws-sdk/middleware-recursion-detection");
var import_middleware_user_agent = require("@aws-sdk/middleware-user-agent");
var import_config_resolver = require("@smithy/config-resolver");
var import_core = require("@smithy/core");
var import_middleware_content_length = require("@smithy/middleware-content-length");
var import_middleware_endpoint = require("@smithy/middleware-endpoint");
var import_middleware_retry = require("@smithy/middleware-retry");

var import_httpAuthSchemeProvider = require("./auth/httpAuthSchemeProvider");

// src/endpoint/EndpointParameters.ts
var resolveClientEndpointParameters = /* @__PURE__ */ __name((options) => {
  return Object.assign(options, {
    useDualstackEndpoint: options.useDualstackEndpoint ?? false,
    useFipsEndpoint: options.useFipsEndpoint ?? false,
    defaultSigningName: "polly"
  });
}, "resolveClientEndpointParameters");
var commonParams = {
  UseFIPS: { type: "builtInParams", name: "useFipsEndpoint" },
  Endpoint: { type: "builtInParams", name: "endpoint" },
  Region: { type: "builtInParams", name: "region" },
  UseDualStack: { type: "builtInParams", name: "useDualstackEndpoint" }
};

// src/PollyClient.ts
var import_runtimeConfig = require("././runtimeConfig");

// src/runtimeExtensions.ts
var import_region_config_resolver = require("@aws-sdk/region-config-resolver");
var import_protocol_http = require("@smithy/protocol-http");
var import_smithy_client = require("@smithy/smithy-client");

// src/auth/httpAuthExtensionConfiguration.ts
var getHttpAuthExtensionConfiguration = /* @__PURE__ */ __name((runtimeConfig) => {
  const _httpAuthSchemes = runtimeConfig.httpAuthSchemes;
  let _httpAuthSchemeProvider = runtimeConfig.httpAuthSchemeProvider;
  let _credentials = runtimeConfig.credentials;
  return {
    setHttpAuthScheme(httpAuthScheme) {
      const index = _httpAuthSchemes.findIndex((scheme) => scheme.schemeId === httpAuthScheme.schemeId);
      if (index === -1) {
        _httpAuthSchemes.push(httpAuthScheme);
      } else {
        _httpAuthSchemes.splice(index, 1, httpAuthScheme);
      }
    },
    httpAuthSchemes() {
      return _httpAuthSchemes;
    },
    setHttpAuthSchemeProvider(httpAuthSchemeProvider) {
      _httpAuthSchemeProvider = httpAuthSchemeProvider;
    },
    httpAuthSchemeProvider() {
      return _httpAuthSchemeProvider;
    },
    setCredentials(credentials) {
      _credentials = credentials;
    },
    credentials() {
      return _credentials;
    }
  };
}, "getHttpAuthExtensionConfiguration");
var resolveHttpAuthRuntimeConfig = /* @__PURE__ */ __name((config) => {
  return {
    httpAuthSchemes: config.httpAuthSchemes(),
    httpAuthSchemeProvider: config.httpAuthSchemeProvider(),
    credentials: config.credentials()
  };
}, "resolveHttpAuthRuntimeConfig");

// src/runtimeExtensions.ts
var resolveRuntimeExtensions = /* @__PURE__ */ __name((runtimeConfig, extensions) => {
  const extensionConfiguration = Object.assign(
    (0, import_region_config_resolver.getAwsRegionExtensionConfiguration)(runtimeConfig),
    (0, import_smithy_client.getDefaultExtensionConfiguration)(runtimeConfig),
    (0, import_protocol_http.getHttpHandlerExtensionConfiguration)(runtimeConfig),
    getHttpAuthExtensionConfiguration(runtimeConfig)
  );
  extensions.forEach((extension) => extension.configure(extensionConfiguration));
  return Object.assign(
    runtimeConfig,
    (0, import_region_config_resolver.resolveAwsRegionExtensionConfiguration)(extensionConfiguration),
    (0, import_smithy_client.resolveDefaultRuntimeConfig)(extensionConfiguration),
    (0, import_protocol_http.resolveHttpHandlerRuntimeConfig)(extensionConfiguration),
    resolveHttpAuthRuntimeConfig(extensionConfiguration)
  );
}, "resolveRuntimeExtensions");

// src/PollyClient.ts
var PollyClient = class extends import_smithy_client.Client {
  static {
    __name(this, "PollyClient");
  }
  /**
   * The resolved configuration of PollyClient class. This is resolved and normalized from the {@link PollyClientConfig | constructor configuration interface}.
   */
  config;
  constructor(...[configuration]) {
    const _config_0 = (0, import_runtimeConfig.getRuntimeConfig)(configuration || {});
    super(_config_0);
    this.initConfig = _config_0;
    const _config_1 = resolveClientEndpointParameters(_config_0);
    const _config_2 = (0, import_middleware_user_agent.resolveUserAgentConfig)(_config_1);
    const _config_3 = (0, import_middleware_retry.resolveRetryConfig)(_config_2);
    const _config_4 = (0, import_config_resolver.resolveRegionConfig)(_config_3);
    const _config_5 = (0, import_middleware_host_header.resolveHostHeaderConfig)(_config_4);
    const _config_6 = (0, import_middleware_endpoint.resolveEndpointConfig)(_config_5);
    const _config_7 = (0, import_httpAuthSchemeProvider.resolveHttpAuthSchemeConfig)(_config_6);
    const _config_8 = resolveRuntimeExtensions(_config_7, configuration?.extensions || []);
    this.config = _config_8;
    this.middlewareStack.use((0, import_middleware_user_agent.getUserAgentPlugin)(this.config));
    this.middlewareStack.use((0, import_middleware_retry.getRetryPlugin)(this.config));
    this.middlewareStack.use((0, import_middleware_content_length.getContentLengthPlugin)(this.config));
    this.middlewareStack.use((0, import_middleware_host_header.getHostHeaderPlugin)(this.config));
    this.middlewareStack.use((0, import_middleware_logger.getLoggerPlugin)(this.config));
    this.middlewareStack.use((0, import_middleware_recursion_detection.getRecursionDetectionPlugin)(this.config));
    this.middlewareStack.use(
      (0, import_core.getHttpAuthSchemeEndpointRuleSetPlugin)(this.config, {
        httpAuthSchemeParametersProvider: import_httpAuthSchemeProvider.defaultPollyHttpAuthSchemeParametersProvider,
        identityProviderConfigProvider: /* @__PURE__ */ __name(async (config) => new import_core.DefaultIdentityProviderConfig({
          "aws.auth#sigv4": config.credentials
        }), "identityProviderConfigProvider")
      })
    );
    this.middlewareStack.use((0, import_core.getHttpSigningPlugin)(this.config));
  }
  /**
   * Destroy underlying resources, like sockets. It's usually not necessary to do this.
   * However in Node.js, it's best to explicitly shut down the client's agent when it is no longer needed.
   * Otherwise, sockets might stay open for quite a long time before the server terminates them.
   */
  destroy() {
    super.destroy();
  }
};

// src/Polly.ts


// src/commands/DeleteLexiconCommand.ts

var import_middleware_serde = require("@smithy/middleware-serde");


// src/protocols/Aws_restJson1.ts
var import_core2 = require("@aws-sdk/core");



// src/models/models_0.ts


// src/models/PollyServiceException.ts

var PollyServiceException = class _PollyServiceException extends import_smithy_client.ServiceException {
  static {
    __name(this, "PollyServiceException");
  }
  /**
   * @internal
   */
  constructor(options) {
    super(options);
    Object.setPrototypeOf(this, _PollyServiceException.prototype);
  }
};

// src/models/models_0.ts
var LexiconNotFoundException = class _LexiconNotFoundException extends PollyServiceException {
  static {
    __name(this, "LexiconNotFoundException");
  }
  name = "LexiconNotFoundException";
  $fault = "client";
  /**
   * @internal
   */
  constructor(opts) {
    super({
      name: "LexiconNotFoundException",
      $fault: "client",
      ...opts
    });
    Object.setPrototypeOf(this, _LexiconNotFoundException.prototype);
  }
};
var ServiceFailureException = class _ServiceFailureException extends PollyServiceException {
  static {
    __name(this, "ServiceFailureException");
  }
  name = "ServiceFailureException";
  $fault = "server";
  /**
   * @internal
   */
  constructor(opts) {
    super({
      name: "ServiceFailureException",
      $fault: "server",
      ...opts
    });
    Object.setPrototypeOf(this, _ServiceFailureException.prototype);
  }
};
var Engine = {
  GENERATIVE: "generative",
  LONG_FORM: "long-form",
  NEURAL: "neural",
  STANDARD: "standard"
};
var LanguageCode = {
  ar_AE: "ar-AE",
  arb: "arb",
  ca_ES: "ca-ES",
  cmn_CN: "cmn-CN",
  cs_CZ: "cs-CZ",
  cy_GB: "cy-GB",
  da_DK: "da-DK",
  de_AT: "de-AT",
  de_CH: "de-CH",
  de_DE: "de-DE",
  en_AU: "en-AU",
  en_GB: "en-GB",
  en_GB_WLS: "en-GB-WLS",
  en_IE: "en-IE",
  en_IN: "en-IN",
  en_NZ: "en-NZ",
  en_SG: "en-SG",
  en_US: "en-US",
  en_ZA: "en-ZA",
  es_ES: "es-ES",
  es_MX: "es-MX",
  es_US: "es-US",
  fi_FI: "fi-FI",
  fr_BE: "fr-BE",
  fr_CA: "fr-CA",
  fr_FR: "fr-FR",
  hi_IN: "hi-IN",
  is_IS: "is-IS",
  it_IT: "it-IT",
  ja_JP: "ja-JP",
  ko_KR: "ko-KR",
  nb_NO: "nb-NO",
  nl_BE: "nl-BE",
  nl_NL: "nl-NL",
  pl_PL: "pl-PL",
  pt_BR: "pt-BR",
  pt_PT: "pt-PT",
  ro_RO: "ro-RO",
  ru_RU: "ru-RU",
  sv_SE: "sv-SE",
  tr_TR: "tr-TR",
  yue_CN: "yue-CN"
};
var Gender = {
  Female: "Female",
  Male: "Male"
};
var VoiceId = {
  Aditi: "Aditi",
  Adriano: "Adriano",
  Amy: "Amy",
  Andres: "Andres",
  Aria: "Aria",
  Arlet: "Arlet",
  Arthur: "Arthur",
  Astrid: "Astrid",
  Ayanda: "Ayanda",
  Bianca: "Bianca",
  Brian: "Brian",
  Burcu: "Burcu",
  Camila: "Camila",
  Carla: "Carla",
  Carmen: "Carmen",
  Celine: "Celine",
  Chantal: "Chantal",
  Conchita: "Conchita",
  Cristiano: "Cristiano",
  Daniel: "Daniel",
  Danielle: "Danielle",
  Dora: "Dora",
  Elin: "Elin",
  Emma: "Emma",
  Enrique: "Enrique",
  Ewa: "Ewa",
  Filiz: "Filiz",
  Gabrielle: "Gabrielle",
  Geraint: "Geraint",
  Giorgio: "Giorgio",
  Gregory: "Gregory",
  Gwyneth: "Gwyneth",
  Hala: "Hala",
  Hannah: "Hannah",
  Hans: "Hans",
  Hiujin: "Hiujin",
  Ida: "Ida",
  Ines: "Ines",
  Isabelle: "Isabelle",
  Ivy: "Ivy",
  Jacek: "Jacek",
  Jan: "Jan",
  Jasmine: "Jasmine",
  Jihye: "Jihye",
  Jitka: "Jitka",
  Joanna: "Joanna",
  Joey: "Joey",
  Justin: "Justin",
  Kajal: "Kajal",
  Karl: "Karl",
  Kazuha: "Kazuha",
  Kendra: "Kendra",
  Kevin: "Kevin",
  Kimberly: "Kimberly",
  Laura: "Laura",
  Lea: "Lea",
  Liam: "Liam",
  Lisa: "Lisa",
  Liv: "Liv",
  Lotte: "Lotte",
  Lucia: "Lucia",
  Lupe: "Lupe",
  Mads: "Mads",
  Maja: "Maja",
  Marlene: "Marlene",
  Mathieu: "Mathieu",
  Matthew: "Matthew",
  Maxim: "Maxim",
  Mia: "Mia",
  Miguel: "Miguel",
  Mizuki: "Mizuki",
  Naja: "Naja",
  Niamh: "Niamh",
  Nicole: "Nicole",
  Ola: "Ola",
  Olivia: "Olivia",
  Pedro: "Pedro",
  Penelope: "Penelope",
  Raveena: "Raveena",
  Remi: "Remi",
  Ricardo: "Ricardo",
  Ruben: "Ruben",
  Russell: "Russell",
  Ruth: "Ruth",
  Sabrina: "Sabrina",
  Salli: "Salli",
  Seoyeon: "Seoyeon",
  Sergio: "Sergio",
  Sofie: "Sofie",
  Stephen: "Stephen",
  Suvi: "Suvi",
  Takumi: "Takumi",
  Tatyana: "Tatyana",
  Thiago: "Thiago",
  Tomoko: "Tomoko",
  Vicki: "Vicki",
  Vitoria: "Vitoria",
  Zayd: "Zayd",
  Zeina: "Zeina",
  Zhiyu: "Zhiyu"
};
var InvalidNextTokenException = class _InvalidNextTokenException extends PollyServiceException {
  static {
    __name(this, "InvalidNextTokenException");
  }
  name = "InvalidNextTokenException";
  $fault = "client";
  /**
   * @internal
   */
  constructor(opts) {
    super({
      name: "InvalidNextTokenException",
      $fault: "client",
      ...opts
    });
    Object.setPrototypeOf(this, _InvalidNextTokenException.prototype);
  }
};
var EngineNotSupportedException = class _EngineNotSupportedException extends PollyServiceException {
  static {
    __name(this, "EngineNotSupportedException");
  }
  name = "EngineNotSupportedException";
  $fault = "client";
  /**
   * @internal
   */
  constructor(opts) {
    super({
      name: "EngineNotSupportedException",
      $fault: "client",
      ...opts
    });
    Object.setPrototypeOf(this, _EngineNotSupportedException.prototype);
  }
};
var OutputFormat = {
  JSON: "json",
  MP3: "mp3",
  OGG_VORBIS: "ogg_vorbis",
  PCM: "pcm"
};
var SpeechMarkType = {
  SENTENCE: "sentence",
  SSML: "ssml",
  VISEME: "viseme",
  WORD: "word"
};
var TaskStatus = {
  COMPLETED: "completed",
  FAILED: "failed",
  IN_PROGRESS: "inProgress",
  SCHEDULED: "scheduled"
};
var TextType = {
  SSML: "ssml",
  TEXT: "text"
};
var InvalidTaskIdException = class _InvalidTaskIdException extends PollyServiceException {
  static {
    __name(this, "InvalidTaskIdException");
  }
  name = "InvalidTaskIdException";
  $fault = "client";
  /**
   * @internal
   */
  constructor(opts) {
    super({
      name: "InvalidTaskIdException",
      $fault: "client",
      ...opts
    });
    Object.setPrototypeOf(this, _InvalidTaskIdException.prototype);
  }
};
var SynthesisTaskNotFoundException = class _SynthesisTaskNotFoundException extends PollyServiceException {
  static {
    __name(this, "SynthesisTaskNotFoundException");
  }
  name = "SynthesisTaskNotFoundException";
  $fault = "client";
  /**
   * @internal
   */
  constructor(opts) {
    super({
      name: "SynthesisTaskNotFoundException",
      $fault: "client",
      ...opts
    });
    Object.setPrototypeOf(this, _SynthesisTaskNotFoundException.prototype);
  }
};
var InvalidLexiconException = class _InvalidLexiconException extends PollyServiceException {
  static {
    __name(this, "InvalidLexiconException");
  }
  name = "InvalidLexiconException";
  $fault = "client";
  /**
   * @internal
   */
  constructor(opts) {
    super({
      name: "InvalidLexiconException",
      $fault: "client",
      ...opts
    });
    Object.setPrototypeOf(this, _InvalidLexiconException.prototype);
  }
};
var InvalidS3BucketException = class _InvalidS3BucketException extends PollyServiceException {
  static {
    __name(this, "InvalidS3BucketException");
  }
  name = "InvalidS3BucketException";
  $fault = "client";
  /**
   * @internal
   */
  constructor(opts) {
    super({
      name: "InvalidS3BucketException",
      $fault: "client",
      ...opts
    });
    Object.setPrototypeOf(this, _InvalidS3BucketException.prototype);
  }
};
var InvalidS3KeyException = class _InvalidS3KeyException extends PollyServiceException {
  static {
    __name(this, "InvalidS3KeyException");
  }
  name = "InvalidS3KeyException";
  $fault = "client";
  /**
   * @internal
   */
  constructor(opts) {
    super({
      name: "InvalidS3KeyException",
      $fault: "client",
      ...opts
    });
    Object.setPrototypeOf(this, _InvalidS3KeyException.prototype);
  }
};
var InvalidSampleRateException = class _InvalidSampleRateException extends PollyServiceException {
  static {
    __name(this, "InvalidSampleRateException");
  }
  name = "InvalidSampleRateException";
  $fault = "client";
  /**
   * @internal
   */
  constructor(opts) {
    super({
      name: "InvalidSampleRateException",
      $fault: "client",
      ...opts
    });
    Object.setPrototypeOf(this, _InvalidSampleRateException.prototype);
  }
};
var InvalidSnsTopicArnException = class _InvalidSnsTopicArnException extends PollyServiceException {
  static {
    __name(this, "InvalidSnsTopicArnException");
  }
  name = "InvalidSnsTopicArnException";
  $fault = "client";
  /**
   * @internal
   */
  constructor(opts) {
    super({
      name: "InvalidSnsTopicArnException",
      $fault: "client",
      ...opts
    });
    Object.setPrototypeOf(this, _InvalidSnsTopicArnException.prototype);
  }
};
var InvalidSsmlException = class _InvalidSsmlException extends PollyServiceException {
  static {
    __name(this, "InvalidSsmlException");
  }
  name = "InvalidSsmlException";
  $fault = "client";
  /**
   * @internal
   */
  constructor(opts) {
    super({
      name: "InvalidSsmlException",
      $fault: "client",
      ...opts
    });
    Object.setPrototypeOf(this, _InvalidSsmlException.prototype);
  }
};
var LanguageNotSupportedException = class _LanguageNotSupportedException extends PollyServiceException {
  static {
    __name(this, "LanguageNotSupportedException");
  }
  name = "LanguageNotSupportedException";
  $fault = "client";
  /**
   * @internal
   */
  constructor(opts) {
    super({
      name: "LanguageNotSupportedException",
      $fault: "client",
      ...opts
    });
    Object.setPrototypeOf(this, _LanguageNotSupportedException.prototype);
  }
};
var LexiconSizeExceededException = class _LexiconSizeExceededException extends PollyServiceException {
  static {
    __name(this, "LexiconSizeExceededException");
  }
  name = "LexiconSizeExceededException";
  $fault = "client";
  /**
   * @internal
   */
  constructor(opts) {
    super({
      name: "LexiconSizeExceededException",
      $fault: "client",
      ...opts
    });
    Object.setPrototypeOf(this, _LexiconSizeExceededException.prototype);
  }
};
var MarksNotSupportedForFormatException = class _MarksNotSupportedForFormatException extends PollyServiceException {
  static {
    __name(this, "MarksNotSupportedForFormatException");
  }
  name = "MarksNotSupportedForFormatException";
  $fault = "client";
  /**
   * @internal
   */
  constructor(opts) {
    super({
      name: "MarksNotSupportedForFormatException",
      $fault: "client",
      ...opts
    });
    Object.setPrototypeOf(this, _MarksNotSupportedForFormatException.prototype);
  }
};
var MaxLexemeLengthExceededException = class _MaxLexemeLengthExceededException extends PollyServiceException {
  static {
    __name(this, "MaxLexemeLengthExceededException");
  }
  name = "MaxLexemeLengthExceededException";
  $fault = "client";
  /**
   * @internal
   */
  constructor(opts) {
    super({
      name: "MaxLexemeLengthExceededException",
      $fault: "client",
      ...opts
    });
    Object.setPrototypeOf(this, _MaxLexemeLengthExceededException.prototype);
  }
};
var MaxLexiconsNumberExceededException = class _MaxLexiconsNumberExceededException extends PollyServiceException {
  static {
    __name(this, "MaxLexiconsNumberExceededException");
  }
  name = "MaxLexiconsNumberExceededException";
  $fault = "client";
  /**
   * @internal
   */
  constructor(opts) {
    super({
      name: "MaxLexiconsNumberExceededException",
      $fault: "client",
      ...opts
    });
    Object.setPrototypeOf(this, _MaxLexiconsNumberExceededException.prototype);
  }
};
var UnsupportedPlsAlphabetException = class _UnsupportedPlsAlphabetException extends PollyServiceException {
  static {
    __name(this, "UnsupportedPlsAlphabetException");
  }
  name = "UnsupportedPlsAlphabetException";
  $fault = "client";
  /**
   * @internal
   */
  constructor(opts) {
    super({
      name: "UnsupportedPlsAlphabetException",
      $fault: "client",
      ...opts
    });
    Object.setPrototypeOf(this, _UnsupportedPlsAlphabetException.prototype);
  }
};
var UnsupportedPlsLanguageException = class _UnsupportedPlsLanguageException extends PollyServiceException {
  static {
    __name(this, "UnsupportedPlsLanguageException");
  }
  name = "UnsupportedPlsLanguageException";
  $fault = "client";
  /**
   * @internal
   */
  constructor(opts) {
    super({
      name: "UnsupportedPlsLanguageException",
      $fault: "client",
      ...opts
    });
    Object.setPrototypeOf(this, _UnsupportedPlsLanguageException.prototype);
  }
};
var SsmlMarksNotSupportedForTextTypeException = class _SsmlMarksNotSupportedForTextTypeException extends PollyServiceException {
  static {
    __name(this, "SsmlMarksNotSupportedForTextTypeException");
  }
  name = "SsmlMarksNotSupportedForTextTypeException";
  $fault = "client";
  /**
   * @internal
   */
  constructor(opts) {
    super({
      name: "SsmlMarksNotSupportedForTextTypeException",
      $fault: "client",
      ...opts
    });
    Object.setPrototypeOf(this, _SsmlMarksNotSupportedForTextTypeException.prototype);
  }
};
var TextLengthExceededException = class _TextLengthExceededException extends PollyServiceException {
  static {
    __name(this, "TextLengthExceededException");
  }
  name = "TextLengthExceededException";
  $fault = "client";
  /**
   * @internal
   */
  constructor(opts) {
    super({
      name: "TextLengthExceededException",
      $fault: "client",
      ...opts
    });
    Object.setPrototypeOf(this, _TextLengthExceededException.prototype);
  }
};
var LexiconFilterSensitiveLog = /* @__PURE__ */ __name((obj) => ({
  ...obj,
  ...obj.Content && { Content: import_smithy_client.SENSITIVE_STRING }
}), "LexiconFilterSensitiveLog");
var GetLexiconOutputFilterSensitiveLog = /* @__PURE__ */ __name((obj) => ({
  ...obj,
  ...obj.Lexicon && { Lexicon: LexiconFilterSensitiveLog(obj.Lexicon) }
}), "GetLexiconOutputFilterSensitiveLog");
var PutLexiconInputFilterSensitiveLog = /* @__PURE__ */ __name((obj) => ({
  ...obj,
  ...obj.Content && { Content: import_smithy_client.SENSITIVE_STRING }
}), "PutLexiconInputFilterSensitiveLog");
var SynthesizeSpeechOutputFilterSensitiveLog = /* @__PURE__ */ __name((obj) => ({
  ...obj
}), "SynthesizeSpeechOutputFilterSensitiveLog");

// src/protocols/Aws_restJson1.ts
var se_DeleteLexiconCommand = /* @__PURE__ */ __name(async (input, context) => {
  const b = (0, import_core.requestBuilder)(input, context);
  const headers = {};
  b.bp("/v1/lexicons/{Name}");
  b.p("Name", () => input.Name, "{Name}", false);
  let body;
  b.m("DELETE").h(headers).b(body);
  return b.build();
}, "se_DeleteLexiconCommand");
var se_DescribeVoicesCommand = /* @__PURE__ */ __name(async (input, context) => {
  const b = (0, import_core.requestBuilder)(input, context);
  const headers = {};
  b.bp("/v1/voices");
  const query = (0, import_smithy_client.map)({
    [_E]: [, input[_E]],
    [_LC]: [, input[_LC]],
    [_IALC]: [() => input.IncludeAdditionalLanguageCodes !== void 0, () => input[_IALC].toString()],
    [_NT]: [, input[_NT]]
  });
  let body;
  b.m("GET").h(headers).q(query).b(body);
  return b.build();
}, "se_DescribeVoicesCommand");
var se_GetLexiconCommand = /* @__PURE__ */ __name(async (input, context) => {
  const b = (0, import_core.requestBuilder)(input, context);
  const headers = {};
  b.bp("/v1/lexicons/{Name}");
  b.p("Name", () => input.Name, "{Name}", false);
  let body;
  b.m("GET").h(headers).b(body);
  return b.build();
}, "se_GetLexiconCommand");
var se_GetSpeechSynthesisTaskCommand = /* @__PURE__ */ __name(async (input, context) => {
  const b = (0, import_core.requestBuilder)(input, context);
  const headers = {};
  b.bp("/v1/synthesisTasks/{TaskId}");
  b.p("TaskId", () => input.TaskId, "{TaskId}", false);
  let body;
  b.m("GET").h(headers).b(body);
  return b.build();
}, "se_GetSpeechSynthesisTaskCommand");
var se_ListLexiconsCommand = /* @__PURE__ */ __name(async (input, context) => {
  const b = (0, import_core.requestBuilder)(input, context);
  const headers = {};
  b.bp("/v1/lexicons");
  const query = (0, import_smithy_client.map)({
    [_NT]: [, input[_NT]]
  });
  let body;
  b.m("GET").h(headers).q(query).b(body);
  return b.build();
}, "se_ListLexiconsCommand");
var se_ListSpeechSynthesisTasksCommand = /* @__PURE__ */ __name(async (input, context) => {
  const b = (0, import_core.requestBuilder)(input, context);
  const headers = {};
  b.bp("/v1/synthesisTasks");
  const query = (0, import_smithy_client.map)({
    [_MR]: [() => input.MaxResults !== void 0, () => input[_MR].toString()],
    [_NT]: [, input[_NT]],
    [_S]: [, input[_S]]
  });
  let body;
  b.m("GET").h(headers).q(query).b(body);
  return b.build();
}, "se_ListSpeechSynthesisTasksCommand");
var se_PutLexiconCommand = /* @__PURE__ */ __name(async (input, context) => {
  const b = (0, import_core.requestBuilder)(input, context);
  const headers = {
    "content-type": "application/json"
  };
  b.bp("/v1/lexicons/{Name}");
  b.p("Name", () => input.Name, "{Name}", false);
  let body;
  body = JSON.stringify(
    (0, import_smithy_client.take)(input, {
      Content: []
    })
  );
  b.m("PUT").h(headers).b(body);
  return b.build();
}, "se_PutLexiconCommand");
var se_StartSpeechSynthesisTaskCommand = /* @__PURE__ */ __name(async (input, context) => {
  const b = (0, import_core.requestBuilder)(input, context);
  const headers = {
    "content-type": "application/json"
  };
  b.bp("/v1/synthesisTasks");
  let body;
  body = JSON.stringify(
    (0, import_smithy_client.take)(input, {
      Engine: [],
      LanguageCode: [],
      LexiconNames: /* @__PURE__ */ __name((_) => (0, import_smithy_client._json)(_), "LexiconNames"),
      OutputFormat: [],
      OutputS3BucketName: [],
      OutputS3KeyPrefix: [],
      SampleRate: [],
      SnsTopicArn: [],
      SpeechMarkTypes: /* @__PURE__ */ __name((_) => (0, import_smithy_client._json)(_), "SpeechMarkTypes"),
      Text: [],
      TextType: [],
      VoiceId: []
    })
  );
  b.m("POST").h(headers).b(body);
  return b.build();
}, "se_StartSpeechSynthesisTaskCommand");
var se_SynthesizeSpeechCommand = /* @__PURE__ */ __name(async (input, context) => {
  const b = (0, import_core.requestBuilder)(input, context);
  const headers = {
    "content-type": "application/json"
  };
  b.bp("/v1/speech");
  let body;
  body = JSON.stringify(
    (0, import_smithy_client.take)(input, {
      Engine: [],
      LanguageCode: [],
      LexiconNames: /* @__PURE__ */ __name((_) => (0, import_smithy_client._json)(_), "LexiconNames"),
      OutputFormat: [],
      SampleRate: [],
      SpeechMarkTypes: /* @__PURE__ */ __name((_) => (0, import_smithy_client._json)(_), "SpeechMarkTypes"),
      Text: [],
      TextType: [],
      VoiceId: []
    })
  );
  b.m("POST").h(headers).b(body);
  return b.build();
}, "se_SynthesizeSpeechCommand");
var de_DeleteLexiconCommand = /* @__PURE__ */ __name(async (output, context) => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return de_CommandError(output, context);
  }
  const contents = (0, import_smithy_client.map)({
    $metadata: deserializeMetadata(output)
  });
  await (0, import_smithy_client.collectBody)(output.body, context);
  return contents;
}, "de_DeleteLexiconCommand");
var de_DescribeVoicesCommand = /* @__PURE__ */ __name(async (output, context) => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return de_CommandError(output, context);
  }
  const contents = (0, import_smithy_client.map)({
    $metadata: deserializeMetadata(output)
  });
  const data = (0, import_smithy_client.expectNonNull)((0, import_smithy_client.expectObject)(await (0, import_core2.parseJsonBody)(output.body, context)), "body");
  const doc = (0, import_smithy_client.take)(data, {
    NextToken: import_smithy_client.expectString,
    Voices: import_smithy_client._json
  });
  Object.assign(contents, doc);
  return contents;
}, "de_DescribeVoicesCommand");
var de_GetLexiconCommand = /* @__PURE__ */ __name(async (output, context) => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return de_CommandError(output, context);
  }
  const contents = (0, import_smithy_client.map)({
    $metadata: deserializeMetadata(output)
  });
  const data = (0, import_smithy_client.expectNonNull)((0, import_smithy_client.expectObject)(await (0, import_core2.parseJsonBody)(output.body, context)), "body");
  const doc = (0, import_smithy_client.take)(data, {
    Lexicon: import_smithy_client._json,
    LexiconAttributes: /* @__PURE__ */ __name((_) => de_LexiconAttributes(_, context), "LexiconAttributes")
  });
  Object.assign(contents, doc);
  return contents;
}, "de_GetLexiconCommand");
var de_GetSpeechSynthesisTaskCommand = /* @__PURE__ */ __name(async (output, context) => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return de_CommandError(output, context);
  }
  const contents = (0, import_smithy_client.map)({
    $metadata: deserializeMetadata(output)
  });
  const data = (0, import_smithy_client.expectNonNull)((0, import_smithy_client.expectObject)(await (0, import_core2.parseJsonBody)(output.body, context)), "body");
  const doc = (0, import_smithy_client.take)(data, {
    SynthesisTask: /* @__PURE__ */ __name((_) => de_SynthesisTask(_, context), "SynthesisTask")
  });
  Object.assign(contents, doc);
  return contents;
}, "de_GetSpeechSynthesisTaskCommand");
var de_ListLexiconsCommand = /* @__PURE__ */ __name(async (output, context) => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return de_CommandError(output, context);
  }
  const contents = (0, import_smithy_client.map)({
    $metadata: deserializeMetadata(output)
  });
  const data = (0, import_smithy_client.expectNonNull)((0, import_smithy_client.expectObject)(await (0, import_core2.parseJsonBody)(output.body, context)), "body");
  const doc = (0, import_smithy_client.take)(data, {
    Lexicons: /* @__PURE__ */ __name((_) => de_LexiconDescriptionList(_, context), "Lexicons"),
    NextToken: import_smithy_client.expectString
  });
  Object.assign(contents, doc);
  return contents;
}, "de_ListLexiconsCommand");
var de_ListSpeechSynthesisTasksCommand = /* @__PURE__ */ __name(async (output, context) => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return de_CommandError(output, context);
  }
  const contents = (0, import_smithy_client.map)({
    $metadata: deserializeMetadata(output)
  });
  const data = (0, import_smithy_client.expectNonNull)((0, import_smithy_client.expectObject)(await (0, import_core2.parseJsonBody)(output.body, context)), "body");
  const doc = (0, import_smithy_client.take)(data, {
    NextToken: import_smithy_client.expectString,
    SynthesisTasks: /* @__PURE__ */ __name((_) => de_SynthesisTasks(_, context), "SynthesisTasks")
  });
  Object.assign(contents, doc);
  return contents;
}, "de_ListSpeechSynthesisTasksCommand");
var de_PutLexiconCommand = /* @__PURE__ */ __name(async (output, context) => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return de_CommandError(output, context);
  }
  const contents = (0, import_smithy_client.map)({
    $metadata: deserializeMetadata(output)
  });
  await (0, import_smithy_client.collectBody)(output.body, context);
  return contents;
}, "de_PutLexiconCommand");
var de_StartSpeechSynthesisTaskCommand = /* @__PURE__ */ __name(async (output, context) => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return de_CommandError(output, context);
  }
  const contents = (0, import_smithy_client.map)({
    $metadata: deserializeMetadata(output)
  });
  const data = (0, import_smithy_client.expectNonNull)((0, import_smithy_client.expectObject)(await (0, import_core2.parseJsonBody)(output.body, context)), "body");
  const doc = (0, import_smithy_client.take)(data, {
    SynthesisTask: /* @__PURE__ */ __name((_) => de_SynthesisTask(_, context), "SynthesisTask")
  });
  Object.assign(contents, doc);
  return contents;
}, "de_StartSpeechSynthesisTaskCommand");
var de_SynthesizeSpeechCommand = /* @__PURE__ */ __name(async (output, context) => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return de_CommandError(output, context);
  }
  const contents = (0, import_smithy_client.map)({
    $metadata: deserializeMetadata(output),
    [_CT]: [, output.headers[_ct]],
    [_RC]: [() => void 0 !== output.headers[_xar], () => (0, import_smithy_client.strictParseInt32)(output.headers[_xar])]
  });
  const data = output.body;
  context.sdkStreamMixin(data);
  contents.AudioStream = data;
  return contents;
}, "de_SynthesizeSpeechCommand");
var de_CommandError = /* @__PURE__ */ __name(async (output, context) => {
  const parsedOutput = {
    ...output,
    body: await (0, import_core2.parseJsonErrorBody)(output.body, context)
  };
  const errorCode = (0, import_core2.loadRestJsonErrorCode)(output, parsedOutput.body);
  switch (errorCode) {
    case "LexiconNotFoundException":
    case "com.amazonaws.polly#LexiconNotFoundException":
      throw await de_LexiconNotFoundExceptionRes(parsedOutput, context);
    case "ServiceFailureException":
    case "com.amazonaws.polly#ServiceFailureException":
      throw await de_ServiceFailureExceptionRes(parsedOutput, context);
    case "InvalidNextTokenException":
    case "com.amazonaws.polly#InvalidNextTokenException":
      throw await de_InvalidNextTokenExceptionRes(parsedOutput, context);
    case "InvalidTaskIdException":
    case "com.amazonaws.polly#InvalidTaskIdException":
      throw await de_InvalidTaskIdExceptionRes(parsedOutput, context);
    case "SynthesisTaskNotFoundException":
    case "com.amazonaws.polly#SynthesisTaskNotFoundException":
      throw await de_SynthesisTaskNotFoundExceptionRes(parsedOutput, context);
    case "InvalidLexiconException":
    case "com.amazonaws.polly#InvalidLexiconException":
      throw await de_InvalidLexiconExceptionRes(parsedOutput, context);
    case "LexiconSizeExceededException":
    case "com.amazonaws.polly#LexiconSizeExceededException":
      throw await de_LexiconSizeExceededExceptionRes(parsedOutput, context);
    case "MaxLexemeLengthExceededException":
    case "com.amazonaws.polly#MaxLexemeLengthExceededException":
      throw await de_MaxLexemeLengthExceededExceptionRes(parsedOutput, context);
    case "MaxLexiconsNumberExceededException":
    case "com.amazonaws.polly#MaxLexiconsNumberExceededException":
      throw await de_MaxLexiconsNumberExceededExceptionRes(parsedOutput, context);
    case "UnsupportedPlsAlphabetException":
    case "com.amazonaws.polly#UnsupportedPlsAlphabetException":
      throw await de_UnsupportedPlsAlphabetExceptionRes(parsedOutput, context);
    case "UnsupportedPlsLanguageException":
    case "com.amazonaws.polly#UnsupportedPlsLanguageException":
      throw await de_UnsupportedPlsLanguageExceptionRes(parsedOutput, context);
    case "EngineNotSupportedException":
    case "com.amazonaws.polly#EngineNotSupportedException":
      throw await de_EngineNotSupportedExceptionRes(parsedOutput, context);
    case "InvalidS3BucketException":
    case "com.amazonaws.polly#InvalidS3BucketException":
      throw await de_InvalidS3BucketExceptionRes(parsedOutput, context);
    case "InvalidS3KeyException":
    case "com.amazonaws.polly#InvalidS3KeyException":
      throw await de_InvalidS3KeyExceptionRes(parsedOutput, context);
    case "InvalidSampleRateException":
    case "com.amazonaws.polly#InvalidSampleRateException":
      throw await de_InvalidSampleRateExceptionRes(parsedOutput, context);
    case "InvalidSnsTopicArnException":
    case "com.amazonaws.polly#InvalidSnsTopicArnException":
      throw await de_InvalidSnsTopicArnExceptionRes(parsedOutput, context);
    case "InvalidSsmlException":
    case "com.amazonaws.polly#InvalidSsmlException":
      throw await de_InvalidSsmlExceptionRes(parsedOutput, context);
    case "LanguageNotSupportedException":
    case "com.amazonaws.polly#LanguageNotSupportedException":
      throw await de_LanguageNotSupportedExceptionRes(parsedOutput, context);
    case "MarksNotSupportedForFormatException":
    case "com.amazonaws.polly#MarksNotSupportedForFormatException":
      throw await de_MarksNotSupportedForFormatExceptionRes(parsedOutput, context);
    case "SsmlMarksNotSupportedForTextTypeException":
    case "com.amazonaws.polly#SsmlMarksNotSupportedForTextTypeException":
      throw await de_SsmlMarksNotSupportedForTextTypeExceptionRes(parsedOutput, context);
    case "TextLengthExceededException":
    case "com.amazonaws.polly#TextLengthExceededException":
      throw await de_TextLengthExceededExceptionRes(parsedOutput, context);
    default:
      const parsedBody = parsedOutput.body;
      return throwDefaultError({
        output,
        parsedBody,
        errorCode
      });
  }
}, "de_CommandError");
var throwDefaultError = (0, import_smithy_client.withBaseException)(PollyServiceException);
var de_EngineNotSupportedExceptionRes = /* @__PURE__ */ __name(async (parsedOutput, context) => {
  const contents = (0, import_smithy_client.map)({});
  const data = parsedOutput.body;
  const doc = (0, import_smithy_client.take)(data, {
    message: import_smithy_client.expectString
  });
  Object.assign(contents, doc);
  const exception = new EngineNotSupportedException({
    $metadata: deserializeMetadata(parsedOutput),
    ...contents
  });
  return (0, import_smithy_client.decorateServiceException)(exception, parsedOutput.body);
}, "de_EngineNotSupportedExceptionRes");
var de_InvalidLexiconExceptionRes = /* @__PURE__ */ __name(async (parsedOutput, context) => {
  const contents = (0, import_smithy_client.map)({});
  const data = parsedOutput.body;
  const doc = (0, import_smithy_client.take)(data, {
    message: import_smithy_client.expectString
  });
  Object.assign(contents, doc);
  const exception = new InvalidLexiconException({
    $metadata: deserializeMetadata(parsedOutput),
    ...contents
  });
  return (0, import_smithy_client.decorateServiceException)(exception, parsedOutput.body);
}, "de_InvalidLexiconExceptionRes");
var de_InvalidNextTokenExceptionRes = /* @__PURE__ */ __name(async (parsedOutput, context) => {
  const contents = (0, import_smithy_client.map)({});
  const data = parsedOutput.body;
  const doc = (0, import_smithy_client.take)(data, {
    message: import_smithy_client.expectString
  });
  Object.assign(contents, doc);
  const exception = new InvalidNextTokenException({
    $metadata: deserializeMetadata(parsedOutput),
    ...contents
  });
  return (0, import_smithy_client.decorateServiceException)(exception, parsedOutput.body);
}, "de_InvalidNextTokenExceptionRes");
var de_InvalidS3BucketExceptionRes = /* @__PURE__ */ __name(async (parsedOutput, context) => {
  const contents = (0, import_smithy_client.map)({});
  const data = parsedOutput.body;
  const doc = (0, import_smithy_client.take)(data, {
    message: import_smithy_client.expectString
  });
  Object.assign(contents, doc);
  const exception = new InvalidS3BucketException({
    $metadata: deserializeMetadata(parsedOutput),
    ...contents
  });
  return (0, import_smithy_client.decorateServiceException)(exception, parsedOutput.body);
}, "de_InvalidS3BucketExceptionRes");
var de_InvalidS3KeyExceptionRes = /* @__PURE__ */ __name(async (parsedOutput, context) => {
  const contents = (0, import_smithy_client.map)({});
  const data = parsedOutput.body;
  const doc = (0, import_smithy_client.take)(data, {
    message: import_smithy_client.expectString
  });
  Object.assign(contents, doc);
  const exception = new InvalidS3KeyException({
    $metadata: deserializeMetadata(parsedOutput),
    ...contents
  });
  return (0, import_smithy_client.decorateServiceException)(exception, parsedOutput.body);
}, "de_InvalidS3KeyExceptionRes");
var de_InvalidSampleRateExceptionRes = /* @__PURE__ */ __name(async (parsedOutput, context) => {
  const contents = (0, import_smithy_client.map)({});
  const data = parsedOutput.body;
  const doc = (0, import_smithy_client.take)(data, {
    message: import_smithy_client.expectString
  });
  Object.assign(contents, doc);
  const exception = new InvalidSampleRateException({
    $metadata: deserializeMetadata(parsedOutput),
    ...contents
  });
  return (0, import_smithy_client.decorateServiceException)(exception, parsedOutput.body);
}, "de_InvalidSampleRateExceptionRes");
var de_InvalidSnsTopicArnExceptionRes = /* @__PURE__ */ __name(async (parsedOutput, context) => {
  const contents = (0, import_smithy_client.map)({});
  const data = parsedOutput.body;
  const doc = (0, import_smithy_client.take)(data, {
    message: import_smithy_client.expectString
  });
  Object.assign(contents, doc);
  const exception = new InvalidSnsTopicArnException({
    $metadata: deserializeMetadata(parsedOutput),
    ...contents
  });
  return (0, import_smithy_client.decorateServiceException)(exception, parsedOutput.body);
}, "de_InvalidSnsTopicArnExceptionRes");
var de_InvalidSsmlExceptionRes = /* @__PURE__ */ __name(async (parsedOutput, context) => {
  const contents = (0, import_smithy_client.map)({});
  const data = parsedOutput.body;
  const doc = (0, import_smithy_client.take)(data, {
    message: import_smithy_client.expectString
  });
  Object.assign(contents, doc);
  const exception = new InvalidSsmlException({
    $metadata: deserializeMetadata(parsedOutput),
    ...contents
  });
  return (0, import_smithy_client.decorateServiceException)(exception, parsedOutput.body);
}, "de_InvalidSsmlExceptionRes");
var de_InvalidTaskIdExceptionRes = /* @__PURE__ */ __name(async (parsedOutput, context) => {
  const contents = (0, import_smithy_client.map)({});
  const data = parsedOutput.body;
  const doc = (0, import_smithy_client.take)(data, {
    message: import_smithy_client.expectString
  });
  Object.assign(contents, doc);
  const exception = new InvalidTaskIdException({
    $metadata: deserializeMetadata(parsedOutput),
    ...contents
  });
  return (0, import_smithy_client.decorateServiceException)(exception, parsedOutput.body);
}, "de_InvalidTaskIdExceptionRes");
var de_LanguageNotSupportedExceptionRes = /* @__PURE__ */ __name(async (parsedOutput, context) => {
  const contents = (0, import_smithy_client.map)({});
  const data = parsedOutput.body;
  const doc = (0, import_smithy_client.take)(data, {
    message: import_smithy_client.expectString
  });
  Object.assign(contents, doc);
  const exception = new LanguageNotSupportedException({
    $metadata: deserializeMetadata(parsedOutput),
    ...contents
  });
  return (0, import_smithy_client.decorateServiceException)(exception, parsedOutput.body);
}, "de_LanguageNotSupportedExceptionRes");
var de_LexiconNotFoundExceptionRes = /* @__PURE__ */ __name(async (parsedOutput, context) => {
  const contents = (0, import_smithy_client.map)({});
  const data = parsedOutput.body;
  const doc = (0, import_smithy_client.take)(data, {
    message: import_smithy_client.expectString
  });
  Object.assign(contents, doc);
  const exception = new LexiconNotFoundException({
    $metadata: deserializeMetadata(parsedOutput),
    ...contents
  });
  return (0, import_smithy_client.decorateServiceException)(exception, parsedOutput.body);
}, "de_LexiconNotFoundExceptionRes");
var de_LexiconSizeExceededExceptionRes = /* @__PURE__ */ __name(async (parsedOutput, context) => {
  const contents = (0, import_smithy_client.map)({});
  const data = parsedOutput.body;
  const doc = (0, import_smithy_client.take)(data, {
    message: import_smithy_client.expectString
  });
  Object.assign(contents, doc);
  const exception = new LexiconSizeExceededException({
    $metadata: deserializeMetadata(parsedOutput),
    ...contents
  });
  return (0, import_smithy_client.decorateServiceException)(exception, parsedOutput.body);
}, "de_LexiconSizeExceededExceptionRes");
var de_MarksNotSupportedForFormatExceptionRes = /* @__PURE__ */ __name(async (parsedOutput, context) => {
  const contents = (0, import_smithy_client.map)({});
  const data = parsedOutput.body;
  const doc = (0, import_smithy_client.take)(data, {
    message: import_smithy_client.expectString
  });
  Object.assign(contents, doc);
  const exception = new MarksNotSupportedForFormatException({
    $metadata: deserializeMetadata(parsedOutput),
    ...contents
  });
  return (0, import_smithy_client.decorateServiceException)(exception, parsedOutput.body);
}, "de_MarksNotSupportedForFormatExceptionRes");
var de_MaxLexemeLengthExceededExceptionRes = /* @__PURE__ */ __name(async (parsedOutput, context) => {
  const contents = (0, import_smithy_client.map)({});
  const data = parsedOutput.body;
  const doc = (0, import_smithy_client.take)(data, {
    message: import_smithy_client.expectString
  });
  Object.assign(contents, doc);
  const exception = new MaxLexemeLengthExceededException({
    $metadata: deserializeMetadata(parsedOutput),
    ...contents
  });
  return (0, import_smithy_client.decorateServiceException)(exception, parsedOutput.body);
}, "de_MaxLexemeLengthExceededExceptionRes");
var de_MaxLexiconsNumberExceededExceptionRes = /* @__PURE__ */ __name(async (parsedOutput, context) => {
  const contents = (0, import_smithy_client.map)({});
  const data = parsedOutput.body;
  const doc = (0, import_smithy_client.take)(data, {
    message: import_smithy_client.expectString
  });
  Object.assign(contents, doc);
  const exception = new MaxLexiconsNumberExceededException({
    $metadata: deserializeMetadata(parsedOutput),
    ...contents
  });
  return (0, import_smithy_client.decorateServiceException)(exception, parsedOutput.body);
}, "de_MaxLexiconsNumberExceededExceptionRes");
var de_ServiceFailureExceptionRes = /* @__PURE__ */ __name(async (parsedOutput, context) => {
  const contents = (0, import_smithy_client.map)({});
  const data = parsedOutput.body;
  const doc = (0, import_smithy_client.take)(data, {
    message: import_smithy_client.expectString
  });
  Object.assign(contents, doc);
  const exception = new ServiceFailureException({
    $metadata: deserializeMetadata(parsedOutput),
    ...contents
  });
  return (0, import_smithy_client.decorateServiceException)(exception, parsedOutput.body);
}, "de_ServiceFailureExceptionRes");
var de_SsmlMarksNotSupportedForTextTypeExceptionRes = /* @__PURE__ */ __name(async (parsedOutput, context) => {
  const contents = (0, import_smithy_client.map)({});
  const data = parsedOutput.body;
  const doc = (0, import_smithy_client.take)(data, {
    message: import_smithy_client.expectString
  });
  Object.assign(contents, doc);
  const exception = new SsmlMarksNotSupportedForTextTypeException({
    $metadata: deserializeMetadata(parsedOutput),
    ...contents
  });
  return (0, import_smithy_client.decorateServiceException)(exception, parsedOutput.body);
}, "de_SsmlMarksNotSupportedForTextTypeExceptionRes");
var de_SynthesisTaskNotFoundExceptionRes = /* @__PURE__ */ __name(async (parsedOutput, context) => {
  const contents = (0, import_smithy_client.map)({});
  const data = parsedOutput.body;
  const doc = (0, import_smithy_client.take)(data, {
    message: import_smithy_client.expectString
  });
  Object.assign(contents, doc);
  const exception = new SynthesisTaskNotFoundException({
    $metadata: deserializeMetadata(parsedOutput),
    ...contents
  });
  return (0, import_smithy_client.decorateServiceException)(exception, parsedOutput.body);
}, "de_SynthesisTaskNotFoundExceptionRes");
var de_TextLengthExceededExceptionRes = /* @__PURE__ */ __name(async (parsedOutput, context) => {
  const contents = (0, import_smithy_client.map)({});
  const data = parsedOutput.body;
  const doc = (0, import_smithy_client.take)(data, {
    message: import_smithy_client.expectString
  });
  Object.assign(contents, doc);
  const exception = new TextLengthExceededException({
    $metadata: deserializeMetadata(parsedOutput),
    ...contents
  });
  return (0, import_smithy_client.decorateServiceException)(exception, parsedOutput.body);
}, "de_TextLengthExceededExceptionRes");
var de_UnsupportedPlsAlphabetExceptionRes = /* @__PURE__ */ __name(async (parsedOutput, context) => {
  const contents = (0, import_smithy_client.map)({});
  const data = parsedOutput.body;
  const doc = (0, import_smithy_client.take)(data, {
    message: import_smithy_client.expectString
  });
  Object.assign(contents, doc);
  const exception = new UnsupportedPlsAlphabetException({
    $metadata: deserializeMetadata(parsedOutput),
    ...contents
  });
  return (0, import_smithy_client.decorateServiceException)(exception, parsedOutput.body);
}, "de_UnsupportedPlsAlphabetExceptionRes");
var de_UnsupportedPlsLanguageExceptionRes = /* @__PURE__ */ __name(async (parsedOutput, context) => {
  const contents = (0, import_smithy_client.map)({});
  const data = parsedOutput.body;
  const doc = (0, import_smithy_client.take)(data, {
    message: import_smithy_client.expectString
  });
  Object.assign(contents, doc);
  const exception = new UnsupportedPlsLanguageException({
    $metadata: deserializeMetadata(parsedOutput),
    ...contents
  });
  return (0, import_smithy_client.decorateServiceException)(exception, parsedOutput.body);
}, "de_UnsupportedPlsLanguageExceptionRes");
var de_LexiconAttributes = /* @__PURE__ */ __name((output, context) => {
  return (0, import_smithy_client.take)(output, {
    Alphabet: import_smithy_client.expectString,
    LanguageCode: import_smithy_client.expectString,
    LastModified: /* @__PURE__ */ __name((_) => (0, import_smithy_client.expectNonNull)((0, import_smithy_client.parseEpochTimestamp)((0, import_smithy_client.expectNumber)(_))), "LastModified"),
    LexemesCount: import_smithy_client.expectInt32,
    LexiconArn: import_smithy_client.expectString,
    Size: import_smithy_client.expectInt32
  });
}, "de_LexiconAttributes");
var de_LexiconDescription = /* @__PURE__ */ __name((output, context) => {
  return (0, import_smithy_client.take)(output, {
    Attributes: /* @__PURE__ */ __name((_) => de_LexiconAttributes(_, context), "Attributes"),
    Name: import_smithy_client.expectString
  });
}, "de_LexiconDescription");
var de_LexiconDescriptionList = /* @__PURE__ */ __name((output, context) => {
  const retVal = (output || []).filter((e) => e != null).map((entry) => {
    return de_LexiconDescription(entry, context);
  });
  return retVal;
}, "de_LexiconDescriptionList");
var de_SynthesisTask = /* @__PURE__ */ __name((output, context) => {
  return (0, import_smithy_client.take)(output, {
    CreationTime: /* @__PURE__ */ __name((_) => (0, import_smithy_client.expectNonNull)((0, import_smithy_client.parseEpochTimestamp)((0, import_smithy_client.expectNumber)(_))), "CreationTime"),
    Engine: import_smithy_client.expectString,
    LanguageCode: import_smithy_client.expectString,
    LexiconNames: import_smithy_client._json,
    OutputFormat: import_smithy_client.expectString,
    OutputUri: import_smithy_client.expectString,
    RequestCharacters: import_smithy_client.expectInt32,
    SampleRate: import_smithy_client.expectString,
    SnsTopicArn: import_smithy_client.expectString,
    SpeechMarkTypes: import_smithy_client._json,
    TaskId: import_smithy_client.expectString,
    TaskStatus: import_smithy_client.expectString,
    TaskStatusReason: import_smithy_client.expectString,
    TextType: import_smithy_client.expectString,
    VoiceId: import_smithy_client.expectString
  });
}, "de_SynthesisTask");
var de_SynthesisTasks = /* @__PURE__ */ __name((output, context) => {
  const retVal = (output || []).filter((e) => e != null).map((entry) => {
    return de_SynthesisTask(entry, context);
  });
  return retVal;
}, "de_SynthesisTasks");
var deserializeMetadata = /* @__PURE__ */ __name((output) => ({
  httpStatusCode: output.statusCode,
  requestId: output.headers["x-amzn-requestid"] ?? output.headers["x-amzn-request-id"] ?? output.headers["x-amz-request-id"],
  extendedRequestId: output.headers["x-amz-id-2"],
  cfId: output.headers["x-amz-cf-id"]
}), "deserializeMetadata");
var _CT = "ContentType";
var _E = "Engine";
var _IALC = "IncludeAdditionalLanguageCodes";
var _LC = "LanguageCode";
var _MR = "MaxResults";
var _NT = "NextToken";
var _RC = "RequestCharacters";
var _S = "Status";
var _ct = "content-type";
var _xar = "x-amzn-requestcharacters";

// src/commands/DeleteLexiconCommand.ts
var DeleteLexiconCommand = class extends import_smithy_client.Command.classBuilder().ep(commonParams).m(function(Command, cs, config, o) {
  return [
    (0, import_middleware_serde.getSerdePlugin)(config, this.serialize, this.deserialize),
    (0, import_middleware_endpoint.getEndpointPlugin)(config, Command.getEndpointParameterInstructions())
  ];
}).s("Parrot_v1", "DeleteLexicon", {}).n("PollyClient", "DeleteLexiconCommand").f(void 0, void 0).ser(se_DeleteLexiconCommand).de(de_DeleteLexiconCommand).build() {
  static {
    __name(this, "DeleteLexiconCommand");
  }
};

// src/commands/DescribeVoicesCommand.ts



var DescribeVoicesCommand = class extends import_smithy_client.Command.classBuilder().ep(commonParams).m(function(Command, cs, config, o) {
  return [
    (0, import_middleware_serde.getSerdePlugin)(config, this.serialize, this.deserialize),
    (0, import_middleware_endpoint.getEndpointPlugin)(config, Command.getEndpointParameterInstructions())
  ];
}).s("Parrot_v1", "DescribeVoices", {}).n("PollyClient", "DescribeVoicesCommand").f(void 0, void 0).ser(se_DescribeVoicesCommand).de(de_DescribeVoicesCommand).build() {
  static {
    __name(this, "DescribeVoicesCommand");
  }
};

// src/commands/GetLexiconCommand.ts



var GetLexiconCommand = class extends import_smithy_client.Command.classBuilder().ep(commonParams).m(function(Command, cs, config, o) {
  return [
    (0, import_middleware_serde.getSerdePlugin)(config, this.serialize, this.deserialize),
    (0, import_middleware_endpoint.getEndpointPlugin)(config, Command.getEndpointParameterInstructions())
  ];
}).s("Parrot_v1", "GetLexicon", {}).n("PollyClient", "GetLexiconCommand").f(void 0, GetLexiconOutputFilterSensitiveLog).ser(se_GetLexiconCommand).de(de_GetLexiconCommand).build() {
  static {
    __name(this, "GetLexiconCommand");
  }
};

// src/commands/GetSpeechSynthesisTaskCommand.ts



var GetSpeechSynthesisTaskCommand = class extends import_smithy_client.Command.classBuilder().ep(commonParams).m(function(Command, cs, config, o) {
  return [
    (0, import_middleware_serde.getSerdePlugin)(config, this.serialize, this.deserialize),
    (0, import_middleware_endpoint.getEndpointPlugin)(config, Command.getEndpointParameterInstructions())
  ];
}).s("Parrot_v1", "GetSpeechSynthesisTask", {}).n("PollyClient", "GetSpeechSynthesisTaskCommand").f(void 0, void 0).ser(se_GetSpeechSynthesisTaskCommand).de(de_GetSpeechSynthesisTaskCommand).build() {
  static {
    __name(this, "GetSpeechSynthesisTaskCommand");
  }
};

// src/commands/ListLexiconsCommand.ts



var ListLexiconsCommand = class extends import_smithy_client.Command.classBuilder().ep(commonParams).m(function(Command, cs, config, o) {
  return [
    (0, import_middleware_serde.getSerdePlugin)(config, this.serialize, this.deserialize),
    (0, import_middleware_endpoint.getEndpointPlugin)(config, Command.getEndpointParameterInstructions())
  ];
}).s("Parrot_v1", "ListLexicons", {}).n("PollyClient", "ListLexiconsCommand").f(void 0, void 0).ser(se_ListLexiconsCommand).de(de_ListLexiconsCommand).build() {
  static {
    __name(this, "ListLexiconsCommand");
  }
};

// src/commands/ListSpeechSynthesisTasksCommand.ts



var ListSpeechSynthesisTasksCommand = class extends import_smithy_client.Command.classBuilder().ep(commonParams).m(function(Command, cs, config, o) {
  return [
    (0, import_middleware_serde.getSerdePlugin)(config, this.serialize, this.deserialize),
    (0, import_middleware_endpoint.getEndpointPlugin)(config, Command.getEndpointParameterInstructions())
  ];
}).s("Parrot_v1", "ListSpeechSynthesisTasks", {}).n("PollyClient", "ListSpeechSynthesisTasksCommand").f(void 0, void 0).ser(se_ListSpeechSynthesisTasksCommand).de(de_ListSpeechSynthesisTasksCommand).build() {
  static {
    __name(this, "ListSpeechSynthesisTasksCommand");
  }
};

// src/commands/PutLexiconCommand.ts



var PutLexiconCommand = class extends import_smithy_client.Command.classBuilder().ep(commonParams).m(function(Command, cs, config, o) {
  return [
    (0, import_middleware_serde.getSerdePlugin)(config, this.serialize, this.deserialize),
    (0, import_middleware_endpoint.getEndpointPlugin)(config, Command.getEndpointParameterInstructions())
  ];
}).s("Parrot_v1", "PutLexicon", {}).n("PollyClient", "PutLexiconCommand").f(PutLexiconInputFilterSensitiveLog, void 0).ser(se_PutLexiconCommand).de(de_PutLexiconCommand).build() {
  static {
    __name(this, "PutLexiconCommand");
  }
};

// src/commands/StartSpeechSynthesisTaskCommand.ts



var StartSpeechSynthesisTaskCommand = class extends import_smithy_client.Command.classBuilder().ep(commonParams).m(function(Command, cs, config, o) {
  return [
    (0, import_middleware_serde.getSerdePlugin)(config, this.serialize, this.deserialize),
    (0, import_middleware_endpoint.getEndpointPlugin)(config, Command.getEndpointParameterInstructions())
  ];
}).s("Parrot_v1", "StartSpeechSynthesisTask", {}).n("PollyClient", "StartSpeechSynthesisTaskCommand").f(void 0, void 0).ser(se_StartSpeechSynthesisTaskCommand).de(de_StartSpeechSynthesisTaskCommand).build() {
  static {
    __name(this, "StartSpeechSynthesisTaskCommand");
  }
};

// src/commands/SynthesizeSpeechCommand.ts



var SynthesizeSpeechCommand = class extends import_smithy_client.Command.classBuilder().ep(commonParams).m(function(Command, cs, config, o) {
  return [
    (0, import_middleware_serde.getSerdePlugin)(config, this.serialize, this.deserialize),
    (0, import_middleware_endpoint.getEndpointPlugin)(config, Command.getEndpointParameterInstructions())
  ];
}).s("Parrot_v1", "SynthesizeSpeech", {}).n("PollyClient", "SynthesizeSpeechCommand").f(void 0, SynthesizeSpeechOutputFilterSensitiveLog).ser(se_SynthesizeSpeechCommand).de(de_SynthesizeSpeechCommand).build() {
  static {
    __name(this, "SynthesizeSpeechCommand");
  }
};

// src/Polly.ts
var commands = {
  DeleteLexiconCommand,
  DescribeVoicesCommand,
  GetLexiconCommand,
  GetSpeechSynthesisTaskCommand,
  ListLexiconsCommand,
  ListSpeechSynthesisTasksCommand,
  PutLexiconCommand,
  StartSpeechSynthesisTaskCommand,
  SynthesizeSpeechCommand
};
var Polly = class extends PollyClient {
  static {
    __name(this, "Polly");
  }
};
(0, import_smithy_client.createAggregatedClient)(commands, Polly);

// src/pagination/ListSpeechSynthesisTasksPaginator.ts

var paginateListSpeechSynthesisTasks = (0, import_core.createPaginator)(PollyClient, ListSpeechSynthesisTasksCommand, "NextToken", "NextToken", "MaxResults");
// Annotate the CommonJS export names for ESM import in node:

0 && (module.exports = {
  PollyServiceException,
  __Client,
  PollyClient,
  Polly,
  $Command,
  DeleteLexiconCommand,
  DescribeVoicesCommand,
  GetLexiconCommand,
  GetSpeechSynthesisTaskCommand,
  ListLexiconsCommand,
  ListSpeechSynthesisTasksCommand,
  PutLexiconCommand,
  StartSpeechSynthesisTaskCommand,
  SynthesizeSpeechCommand,
  paginateListSpeechSynthesisTasks,
  LexiconNotFoundException,
  ServiceFailureException,
  Engine,
  LanguageCode,
  Gender,
  VoiceId,
  InvalidNextTokenException,
  EngineNotSupportedException,
  OutputFormat,
  SpeechMarkType,
  TaskStatus,
  TextType,
  InvalidTaskIdException,
  SynthesisTaskNotFoundException,
  InvalidLexiconException,
  InvalidS3BucketException,
  InvalidS3KeyException,
  InvalidSampleRateException,
  InvalidSnsTopicArnException,
  InvalidSsmlException,
  LanguageNotSupportedException,
  LexiconSizeExceededException,
  MarksNotSupportedForFormatException,
  MaxLexemeLengthExceededException,
  MaxLexiconsNumberExceededException,
  UnsupportedPlsAlphabetException,
  UnsupportedPlsLanguageException,
  SsmlMarksNotSupportedForTextTypeException,
  TextLengthExceededException,
  LexiconFilterSensitiveLog,
  GetLexiconOutputFilterSensitiveLog,
  PutLexiconInputFilterSensitiveLog,
  SynthesizeSpeechOutputFilterSensitiveLog
});

