import { HttpRequest as __HttpRequest, HttpResponse as __HttpResponse } from "@smithy/protocol-http";
import { SdkStreamSerdeContext as __SdkStreamSerdeContext, SerdeContext as __SerdeContext } from "@smithy/types";
import { DeleteLexiconCommandInput, DeleteLexiconCommandOutput } from "../commands/DeleteLexiconCommand";
import { DescribeVoicesCommandInput, DescribeVoicesCommandOutput } from "../commands/DescribeVoicesCommand";
import { GetLexiconCommandInput, GetLexiconCommandOutput } from "../commands/GetLexiconCommand";
import { GetSpeechSynthesisTaskCommandInput, GetSpeechSynthesisTaskCommandOutput } from "../commands/GetSpeechSynthesisTaskCommand";
import { ListLexiconsCommandInput, ListLexiconsCommandOutput } from "../commands/ListLexiconsCommand";
import { ListSpeechSynthesisTasksCommandInput, ListSpeechSynthesisTasksCommandOutput } from "../commands/ListSpeechSynthesisTasksCommand";
import { PutLexiconCommandInput, PutLexiconCommandOutput } from "../commands/PutLexiconCommand";
import { StartSpeechSynthesisTaskCommandInput, StartSpeechSynthesisTaskCommandOutput } from "../commands/StartSpeechSynthesisTaskCommand";
import { SynthesizeSpeechCommandInput, SynthesizeSpeechCommandOutput } from "../commands/SynthesizeSpeechCommand";
/**
 * serializeAws_restJson1DeleteLexiconCommand
 */
export declare const se_DeleteLexiconCommand: (input: DeleteLexiconCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1DescribeVoicesCommand
 */
export declare const se_DescribeVoicesCommand: (input: DescribeVoicesCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1GetLexiconCommand
 */
export declare const se_GetLexiconCommand: (input: GetLexiconCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1GetSpeechSynthesisTaskCommand
 */
export declare const se_GetSpeechSynthesisTaskCommand: (input: GetSpeechSynthesisTaskCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1ListLexiconsCommand
 */
export declare const se_ListLexiconsCommand: (input: ListLexiconsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1ListSpeechSynthesisTasksCommand
 */
export declare const se_ListSpeechSynthesisTasksCommand: (input: ListSpeechSynthesisTasksCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1PutLexiconCommand
 */
export declare const se_PutLexiconCommand: (input: PutLexiconCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1StartSpeechSynthesisTaskCommand
 */
export declare const se_StartSpeechSynthesisTaskCommand: (input: StartSpeechSynthesisTaskCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1SynthesizeSpeechCommand
 */
export declare const se_SynthesizeSpeechCommand: (input: SynthesizeSpeechCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * deserializeAws_restJson1DeleteLexiconCommand
 */
export declare const de_DeleteLexiconCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DeleteLexiconCommandOutput>;
/**
 * deserializeAws_restJson1DescribeVoicesCommand
 */
export declare const de_DescribeVoicesCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DescribeVoicesCommandOutput>;
/**
 * deserializeAws_restJson1GetLexiconCommand
 */
export declare const de_GetLexiconCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<GetLexiconCommandOutput>;
/**
 * deserializeAws_restJson1GetSpeechSynthesisTaskCommand
 */
export declare const de_GetSpeechSynthesisTaskCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<GetSpeechSynthesisTaskCommandOutput>;
/**
 * deserializeAws_restJson1ListLexiconsCommand
 */
export declare const de_ListLexiconsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListLexiconsCommandOutput>;
/**
 * deserializeAws_restJson1ListSpeechSynthesisTasksCommand
 */
export declare const de_ListSpeechSynthesisTasksCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListSpeechSynthesisTasksCommandOutput>;
/**
 * deserializeAws_restJson1PutLexiconCommand
 */
export declare const de_PutLexiconCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<PutLexiconCommandOutput>;
/**
 * deserializeAws_restJson1StartSpeechSynthesisTaskCommand
 */
export declare const de_StartSpeechSynthesisTaskCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<StartSpeechSynthesisTaskCommandOutput>;
/**
 * deserializeAws_restJson1SynthesizeSpeechCommand
 */
export declare const de_SynthesizeSpeechCommand: (output: __HttpResponse, context: __SerdeContext & __SdkStreamSerdeContext) => Promise<SynthesizeSpeechCommandOutput>;
