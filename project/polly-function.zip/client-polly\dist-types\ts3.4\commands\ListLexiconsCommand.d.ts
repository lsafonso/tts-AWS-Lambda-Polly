import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { ListLexiconsInput, ListLexiconsOutput } from "../models/models_0";
import {
  PollyClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../PollyClient";
export { __MetadataBearer };
export { $Command };
export interface ListLexiconsCommandInput extends ListLexiconsInput {}
export interface ListLexiconsCommandOutput
  extends ListLexiconsOutput,
    __MetadataBearer {}
declare const ListLexiconsCommand_base: {
  new (
    input: ListLexiconsCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListLexiconsCommandInput,
    ListLexiconsCommandOutput,
    PollyClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [ListLexiconsCommandInput]
  ): import("@smithy/smithy-client").CommandImpl<
    ListLexiconsCommandInput,
    ListLexiconsCommandOutput,
    PollyClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ListLexiconsCommand extends ListLexiconsCommand_base {
  protected static __types: {
    api: {
      input: ListLexiconsInput;
      output: ListLexiconsOutput;
    };
    sdk: {
      input: ListLexiconsCommandInput;
      output: ListLexiconsCommandOutput;
    };
  };
}
