export declare const getDateHeader: (response: unknown) => string | undefined;
