import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  ListSpeechSynthesisTasksInput,
  ListSpeechSynthesisTasksOutput,
} from "../models/models_0";
import {
  PollyClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../PollyClient";
export { __MetadataBearer };
export { $Command };
export interface ListSpeechSynthesisTasksCommandInput
  extends ListSpeechSynthesisTasksInput {}
export interface ListSpeechSynthesisTasksCommandOutput
  extends ListSpeechSynthesisTasksOutput,
    __MetadataBearer {}
declare const ListSpeechSynthesisTasksCommand_base: {
  new (
    input: ListSpeechSynthesisTasksCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ListSpeechSynthesisTasksCommandInput,
    ListSpeechSynthesisTasksCommandOutput,
    PollyClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [ListSpeechSynthesisTasksCommandInput]
  ): import("@smithy/smithy-client").CommandImpl<
    ListSpeechSynthesisTasksCommandInput,
    ListSpeechSynthesisTasksCommandOutput,
    PollyClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ListSpeechSynthesisTasksCommand extends ListSpeechSynthesisTasksCommand_base {
  protected static __types: {
    api: {
      input: ListSpeechSynthesisTasksInput;
      output: ListSpeechSynthesisTasksOutput;
    };
    sdk: {
      input: ListSpeechSynthesisTasksCommandInput;
      output: ListSpeechSynthesisTasksCommandOutput;
    };
  };
}
