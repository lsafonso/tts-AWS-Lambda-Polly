import { loadRestJsonErrorCode, parseJsonBody as parseBody, parseJsonErrorBody as parseErrorBody } from "@aws-sdk/core";
import { requestBuilder as rb } from "@smithy/core";
import { _json, collectBody, decorateServiceException as __decorateServiceException, expectInt32 as __expectInt32, expectNonNull as __expectNonNull, expectNumber as __expectNumber, expectObject as __expectObject, expectString as __expectString, map, parseEpochTimestamp as __parseEpochTimestamp, strictParseInt32 as __strictParseInt32, take, withBaseException, } from "@smithy/smithy-client";
import { EngineNotSupportedException, InvalidLexiconException, InvalidNextTokenException, InvalidS3BucketException, InvalidS3KeyException, InvalidSampleRateException, InvalidSnsTopicArnException, InvalidSsmlException, InvalidTaskIdException, LanguageNotSupportedException, LexiconNotFoundException, LexiconSizeExceededException, MarksNotSupportedForFormatException, MaxLexemeLengthExceededException, MaxLexiconsNumberExceededException, ServiceFailureException, SsmlMarksNotSupportedForTextTypeException, SynthesisTaskNotFoundException, TextLengthExceededException, UnsupportedPlsAlphabetException, UnsupportedPlsLanguageException, } from "../models/models_0";
import { PollyServiceException as __BaseException } from "../models/PollyServiceException";
export const se_DeleteLexiconCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/v1/lexicons/{Name}");
    b.p("Name", () => input.Name, "{Name}", false);
    let body;
    b.m("DELETE").h(headers).b(body);
    return b.build();
};
export const se_DescribeVoicesCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/v1/voices");
    const query = map({
        [_E]: [, input[_E]],
        [_LC]: [, input[_LC]],
        [_IALC]: [() => input.IncludeAdditionalLanguageCodes !== void 0, () => input[_IALC].toString()],
        [_NT]: [, input[_NT]],
    });
    let body;
    b.m("GET").h(headers).q(query).b(body);
    return b.build();
};
export const se_GetLexiconCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/v1/lexicons/{Name}");
    b.p("Name", () => input.Name, "{Name}", false);
    let body;
    b.m("GET").h(headers).b(body);
    return b.build();
};
export const se_GetSpeechSynthesisTaskCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/v1/synthesisTasks/{TaskId}");
    b.p("TaskId", () => input.TaskId, "{TaskId}", false);
    let body;
    b.m("GET").h(headers).b(body);
    return b.build();
};
export const se_ListLexiconsCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/v1/lexicons");
    const query = map({
        [_NT]: [, input[_NT]],
    });
    let body;
    b.m("GET").h(headers).q(query).b(body);
    return b.build();
};
export const se_ListSpeechSynthesisTasksCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/v1/synthesisTasks");
    const query = map({
        [_MR]: [() => input.MaxResults !== void 0, () => input[_MR].toString()],
        [_NT]: [, input[_NT]],
        [_S]: [, input[_S]],
    });
    let body;
    b.m("GET").h(headers).q(query).b(body);
    return b.build();
};
export const se_PutLexiconCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/v1/lexicons/{Name}");
    b.p("Name", () => input.Name, "{Name}", false);
    let body;
    body = JSON.stringify(take(input, {
        Content: [],
    }));
    b.m("PUT").h(headers).b(body);
    return b.build();
};
export const se_StartSpeechSynthesisTaskCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/v1/synthesisTasks");
    let body;
    body = JSON.stringify(take(input, {
        Engine: [],
        LanguageCode: [],
        LexiconNames: (_) => _json(_),
        OutputFormat: [],
        OutputS3BucketName: [],
        OutputS3KeyPrefix: [],
        SampleRate: [],
        SnsTopicArn: [],
        SpeechMarkTypes: (_) => _json(_),
        Text: [],
        TextType: [],
        VoiceId: [],
    }));
    b.m("POST").h(headers).b(body);
    return b.build();
};
export const se_SynthesizeSpeechCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/v1/speech");
    let body;
    body = JSON.stringify(take(input, {
        Engine: [],
        LanguageCode: [],
        LexiconNames: (_) => _json(_),
        OutputFormat: [],
        SampleRate: [],
        SpeechMarkTypes: (_) => _json(_),
        Text: [],
        TextType: [],
        VoiceId: [],
    }));
    b.m("POST").h(headers).b(body);
    return b.build();
};
export const de_DeleteLexiconCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    await collectBody(output.body, context);
    return contents;
};
export const de_DescribeVoicesCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        NextToken: __expectString,
        Voices: _json,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_GetLexiconCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        Lexicon: _json,
        LexiconAttributes: (_) => de_LexiconAttributes(_, context),
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_GetSpeechSynthesisTaskCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        SynthesisTask: (_) => de_SynthesisTask(_, context),
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_ListLexiconsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        Lexicons: (_) => de_LexiconDescriptionList(_, context),
        NextToken: __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_ListSpeechSynthesisTasksCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        NextToken: __expectString,
        SynthesisTasks: (_) => de_SynthesisTasks(_, context),
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_PutLexiconCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    await collectBody(output.body, context);
    return contents;
};
export const de_StartSpeechSynthesisTaskCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        SynthesisTask: (_) => de_SynthesisTask(_, context),
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_SynthesizeSpeechCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
        [_CT]: [, output.headers[_ct]],
        [_RC]: [() => void 0 !== output.headers[_xar], () => __strictParseInt32(output.headers[_xar])],
    });
    const data = output.body;
    context.sdkStreamMixin(data);
    contents.AudioStream = data;
    return contents;
};
const de_CommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "LexiconNotFoundException":
        case "com.amazonaws.polly#LexiconNotFoundException":
            throw await de_LexiconNotFoundExceptionRes(parsedOutput, context);
        case "ServiceFailureException":
        case "com.amazonaws.polly#ServiceFailureException":
            throw await de_ServiceFailureExceptionRes(parsedOutput, context);
        case "InvalidNextTokenException":
        case "com.amazonaws.polly#InvalidNextTokenException":
            throw await de_InvalidNextTokenExceptionRes(parsedOutput, context);
        case "InvalidTaskIdException":
        case "com.amazonaws.polly#InvalidTaskIdException":
            throw await de_InvalidTaskIdExceptionRes(parsedOutput, context);
        case "SynthesisTaskNotFoundException":
        case "com.amazonaws.polly#SynthesisTaskNotFoundException":
            throw await de_SynthesisTaskNotFoundExceptionRes(parsedOutput, context);
        case "InvalidLexiconException":
        case "com.amazonaws.polly#InvalidLexiconException":
            throw await de_InvalidLexiconExceptionRes(parsedOutput, context);
        case "LexiconSizeExceededException":
        case "com.amazonaws.polly#LexiconSizeExceededException":
            throw await de_LexiconSizeExceededExceptionRes(parsedOutput, context);
        case "MaxLexemeLengthExceededException":
        case "com.amazonaws.polly#MaxLexemeLengthExceededException":
            throw await de_MaxLexemeLengthExceededExceptionRes(parsedOutput, context);
        case "MaxLexiconsNumberExceededException":
        case "com.amazonaws.polly#MaxLexiconsNumberExceededException":
            throw await de_MaxLexiconsNumberExceededExceptionRes(parsedOutput, context);
        case "UnsupportedPlsAlphabetException":
        case "com.amazonaws.polly#UnsupportedPlsAlphabetException":
            throw await de_UnsupportedPlsAlphabetExceptionRes(parsedOutput, context);
        case "UnsupportedPlsLanguageException":
        case "com.amazonaws.polly#UnsupportedPlsLanguageException":
            throw await de_UnsupportedPlsLanguageExceptionRes(parsedOutput, context);
        case "EngineNotSupportedException":
        case "com.amazonaws.polly#EngineNotSupportedException":
            throw await de_EngineNotSupportedExceptionRes(parsedOutput, context);
        case "InvalidS3BucketException":
        case "com.amazonaws.polly#InvalidS3BucketException":
            throw await de_InvalidS3BucketExceptionRes(parsedOutput, context);
        case "InvalidS3KeyException":
        case "com.amazonaws.polly#InvalidS3KeyException":
            throw await de_InvalidS3KeyExceptionRes(parsedOutput, context);
        case "InvalidSampleRateException":
        case "com.amazonaws.polly#InvalidSampleRateException":
            throw await de_InvalidSampleRateExceptionRes(parsedOutput, context);
        case "InvalidSnsTopicArnException":
        case "com.amazonaws.polly#InvalidSnsTopicArnException":
            throw await de_InvalidSnsTopicArnExceptionRes(parsedOutput, context);
        case "InvalidSsmlException":
        case "com.amazonaws.polly#InvalidSsmlException":
            throw await de_InvalidSsmlExceptionRes(parsedOutput, context);
        case "LanguageNotSupportedException":
        case "com.amazonaws.polly#LanguageNotSupportedException":
            throw await de_LanguageNotSupportedExceptionRes(parsedOutput, context);
        case "MarksNotSupportedForFormatException":
        case "com.amazonaws.polly#MarksNotSupportedForFormatException":
            throw await de_MarksNotSupportedForFormatExceptionRes(parsedOutput, context);
        case "SsmlMarksNotSupportedForTextTypeException":
        case "com.amazonaws.polly#SsmlMarksNotSupportedForTextTypeException":
            throw await de_SsmlMarksNotSupportedForTextTypeExceptionRes(parsedOutput, context);
        case "TextLengthExceededException":
        case "com.amazonaws.polly#TextLengthExceededException":
            throw await de_TextLengthExceededExceptionRes(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode,
            });
    }
};
const throwDefaultError = withBaseException(__BaseException);
const de_EngineNotSupportedExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new EngineNotSupportedException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_InvalidLexiconExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new InvalidLexiconException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_InvalidNextTokenExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new InvalidNextTokenException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_InvalidS3BucketExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new InvalidS3BucketException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_InvalidS3KeyExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new InvalidS3KeyException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_InvalidSampleRateExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new InvalidSampleRateException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_InvalidSnsTopicArnExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new InvalidSnsTopicArnException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_InvalidSsmlExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new InvalidSsmlException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_InvalidTaskIdExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new InvalidTaskIdException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_LanguageNotSupportedExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new LanguageNotSupportedException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_LexiconNotFoundExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new LexiconNotFoundException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_LexiconSizeExceededExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new LexiconSizeExceededException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_MarksNotSupportedForFormatExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new MarksNotSupportedForFormatException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_MaxLexemeLengthExceededExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new MaxLexemeLengthExceededException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_MaxLexiconsNumberExceededExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new MaxLexiconsNumberExceededException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_ServiceFailureExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new ServiceFailureException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_SsmlMarksNotSupportedForTextTypeExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new SsmlMarksNotSupportedForTextTypeException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_SynthesisTaskNotFoundExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new SynthesisTaskNotFoundException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_TextLengthExceededExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new TextLengthExceededException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_UnsupportedPlsAlphabetExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new UnsupportedPlsAlphabetException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_UnsupportedPlsLanguageExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new UnsupportedPlsLanguageException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_LexiconAttributes = (output, context) => {
    return take(output, {
        Alphabet: __expectString,
        LanguageCode: __expectString,
        LastModified: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        LexemesCount: __expectInt32,
        LexiconArn: __expectString,
        Size: __expectInt32,
    });
};
const de_LexiconDescription = (output, context) => {
    return take(output, {
        Attributes: (_) => de_LexiconAttributes(_, context),
        Name: __expectString,
    });
};
const de_LexiconDescriptionList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_LexiconDescription(entry, context);
    });
    return retVal;
};
const de_SynthesisTask = (output, context) => {
    return take(output, {
        CreationTime: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        Engine: __expectString,
        LanguageCode: __expectString,
        LexiconNames: _json,
        OutputFormat: __expectString,
        OutputUri: __expectString,
        RequestCharacters: __expectInt32,
        SampleRate: __expectString,
        SnsTopicArn: __expectString,
        SpeechMarkTypes: _json,
        TaskId: __expectString,
        TaskStatus: __expectString,
        TaskStatusReason: __expectString,
        TextType: __expectString,
        VoiceId: __expectString,
    });
};
const de_SynthesisTasks = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_SynthesisTask(entry, context);
    });
    return retVal;
};
const deserializeMetadata = (output) => ({
    httpStatusCode: output.statusCode,
    requestId: output.headers["x-amzn-requestid"] ?? output.headers["x-amzn-request-id"] ?? output.headers["x-amz-request-id"],
    extendedRequestId: output.headers["x-amz-id-2"],
    cfId: output.headers["x-amz-cf-id"],
});
const collectBodyString = (streamBody, context) => collectBody(streamBody, context).then((body) => context.utf8Encoder(body));
const _CT = "ContentType";
const _E = "Engine";
const _IALC = "IncludeAdditionalLanguageCodes";
const _LC = "LanguageCode";
const _MR = "MaxResults";
const _NT = "NextToken";
const _RC = "RequestCharacters";
const _S = "Status";
const _ct = "content-type";
const _xar = "x-amzn-requestcharacters";
