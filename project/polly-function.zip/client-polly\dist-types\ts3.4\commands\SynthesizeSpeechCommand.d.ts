import { Command as $Command } from "@smithy/smithy-client";
import {
  MetadataBearer as __MetadataBearer,
  StreamingBlobPayloadOutputTypes,
} from "@smithy/types";
import {
  SynthesizeSpeechInput,
  SynthesizeSpeechOutput,
} from "../models/models_0";
import {
  PollyClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../PollyClient";
export { __MetadataBearer };
export { $Command };
export interface SynthesizeSpeechCommandInput extends SynthesizeSpeechInput {}
export interface SynthesizeSpeechCommandOutput
  extends Pick<
      SynthesizeSpeechOutput,
      Exclude<keyof SynthesizeSpeechOutput, "AudioStream">
    >,
    __MetadataBearer {
  AudioStream?: StreamingBlobPayloadOutputTypes;
}
declare const SynthesizeSpeechCommand_base: {
  new (
    input: SynthesizeSpeechCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    SynthesizeSpeechCommandInput,
    SynthesizeSpeechCommandOutput,
    PollyClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    input: SynthesizeSpeechCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    SynthesizeSpeechCommandInput,
    SynthesizeSpeechCommandOutput,
    PollyClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class SynthesizeSpeechCommand extends SynthesizeSpeechCommand_base {
  protected static __types: {
    api: {
      input: SynthesizeSpeechInput;
      output: SynthesizeSpeechOutput;
    };
    sdk: {
      input: SynthesizeSpeechCommandInput;
      output: SynthesizeSpeechCommandOutput;
    };
  };
}
