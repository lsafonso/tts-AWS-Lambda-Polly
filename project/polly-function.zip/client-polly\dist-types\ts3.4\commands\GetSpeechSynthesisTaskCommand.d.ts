import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  GetSpeechSynthesisTaskInput,
  GetSpeechSynthesisTaskOutput,
} from "../models/models_0";
import {
  PollyClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../PollyClient";
export { __MetadataBearer };
export { $Command };
export interface GetSpeechSynthesisTaskCommandInput
  extends GetSpeechSynthesisTaskInput {}
export interface GetSpeechSynthesisTaskCommandOutput
  extends GetSpeechSynthesisTaskOutput,
    __MetadataBearer {}
declare const GetSpeechSynthesisTaskCommand_base: {
  new (
    input: GetSpeechSynthesisTaskCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    GetSpeechSynthesisTaskCommandInput,
    GetSpeechSynthesisTaskCommandOutput,
    PollyClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    input: GetSpeechSynthesisTaskCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    GetSpeechSynthesisTaskCommandInput,
    GetSpeechSynthesisTaskCommandOutput,
    PollyClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class GetSpeechSynthesisTaskCommand extends GetSpeechSynthesisTaskCommand_base {
  protected static __types: {
    api: {
      input: GetSpeechSynthesisTaskInput;
      output: GetSpeechSynthesisTaskOutput;
    };
    sdk: {
      input: GetSpeechSynthesisTaskCommandInput;
      output: GetSpeechSynthesisTaskCommandOutput;
    };
  };
}
