import { Paginator } from "@smithy/types";
import { ListSpeechSynthesisTasksCommandInput, ListSpeechSynthesisTasksCommandOutput } from "../commands/ListSpeechSynthesisTasksCommand";
import { PollyPaginationConfiguration } from "./Interfaces";
/**
 * @public
 */
export declare const paginateListSpeechSynthesisTasks: (config: PollyPaginationConfiguration, input: ListSpeechSynthesisTasksCommandInput, ...rest: any[]) => Paginator<ListSpeechSynthesisTasksCommandOutput>;
