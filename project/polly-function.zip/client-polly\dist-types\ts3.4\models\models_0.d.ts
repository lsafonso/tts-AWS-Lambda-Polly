import { ExceptionOptionType as __ExceptionOptionType } from "@smithy/smithy-client";
import { StreamingBlobTypes } from "@smithy/types";
import { PollyServiceException as __BaseException } from "./PollyServiceException";
export interface DeleteLexiconInput {
  Name: string | undefined;
}
export interface DeleteLexiconOutput {}
export declare class LexiconNotFoundException extends __BaseException {
  readonly name: "LexiconNotFoundException";
  readonly $fault: "client";
  constructor(
    opts: __ExceptionOptionType<LexiconNotFoundException, __BaseException>
  );
}
export declare class ServiceFailureException extends __BaseException {
  readonly name: "ServiceFailureException";
  readonly $fault: "server";
  constructor(
    opts: __ExceptionOptionType<ServiceFailureException, __BaseException>
  );
}
export declare const Engine: {
  readonly GENERATIVE: "generative";
  readonly LONG_FORM: "long-form";
  readonly NEURAL: "neural";
  readonly STANDARD: "standard";
};
export type Engine = (typeof Engine)[keyof typeof Engine];
export declare const LanguageCode: {
  readonly ar_AE: "ar-AE";
  readonly arb: "arb";
  readonly ca_ES: "ca-ES";
  readonly cmn_CN: "cmn-CN";
  readonly cs_CZ: "cs-CZ";
  readonly cy_GB: "cy-GB";
  readonly da_DK: "da-DK";
  readonly de_AT: "de-AT";
  readonly de_CH: "de-CH";
  readonly de_DE: "de-DE";
  readonly en_AU: "en-AU";
  readonly en_GB: "en-GB";
  readonly en_GB_WLS: "en-GB-WLS";
  readonly en_IE: "en-IE";
  readonly en_IN: "en-IN";
  readonly en_NZ: "en-NZ";
  readonly en_SG: "en-SG";
  readonly en_US: "en-US";
  readonly en_ZA: "en-ZA";
  readonly es_ES: "es-ES";
  readonly es_MX: "es-MX";
  readonly es_US: "es-US";
  readonly fi_FI: "fi-FI";
  readonly fr_BE: "fr-BE";
  readonly fr_CA: "fr-CA";
  readonly fr_FR: "fr-FR";
  readonly hi_IN: "hi-IN";
  readonly is_IS: "is-IS";
  readonly it_IT: "it-IT";
  readonly ja_JP: "ja-JP";
  readonly ko_KR: "ko-KR";
  readonly nb_NO: "nb-NO";
  readonly nl_BE: "nl-BE";
  readonly nl_NL: "nl-NL";
  readonly pl_PL: "pl-PL";
  readonly pt_BR: "pt-BR";
  readonly pt_PT: "pt-PT";
  readonly ro_RO: "ro-RO";
  readonly ru_RU: "ru-RU";
  readonly sv_SE: "sv-SE";
  readonly tr_TR: "tr-TR";
  readonly yue_CN: "yue-CN";
};
export type LanguageCode = (typeof LanguageCode)[keyof typeof LanguageCode];
export interface DescribeVoicesInput {
  Engine?: Engine | undefined;
  LanguageCode?: LanguageCode | undefined;
  IncludeAdditionalLanguageCodes?: boolean | undefined;
  NextToken?: string | undefined;
}
export declare const Gender: {
  readonly Female: "Female";
  readonly Male: "Male";
};
export type Gender = (typeof Gender)[keyof typeof Gender];
export declare const VoiceId: {
  readonly Aditi: "Aditi";
  readonly Adriano: "Adriano";
  readonly Amy: "Amy";
  readonly Andres: "Andres";
  readonly Aria: "Aria";
  readonly Arlet: "Arlet";
  readonly Arthur: "Arthur";
  readonly Astrid: "Astrid";
  readonly Ayanda: "Ayanda";
  readonly Bianca: "Bianca";
  readonly Brian: "Brian";
  readonly Burcu: "Burcu";
  readonly Camila: "Camila";
  readonly Carla: "Carla";
  readonly Carmen: "Carmen";
  readonly Celine: "Celine";
  readonly Chantal: "Chantal";
  readonly Conchita: "Conchita";
  readonly Cristiano: "Cristiano";
  readonly Daniel: "Daniel";
  readonly Danielle: "Danielle";
  readonly Dora: "Dora";
  readonly Elin: "Elin";
  readonly Emma: "Emma";
  readonly Enrique: "Enrique";
  readonly Ewa: "Ewa";
  readonly Filiz: "Filiz";
  readonly Gabrielle: "Gabrielle";
  readonly Geraint: "Geraint";
  readonly Giorgio: "Giorgio";
  readonly Gregory: "Gregory";
  readonly Gwyneth: "Gwyneth";
  readonly Hala: "Hala";
  readonly Hannah: "Hannah";
  readonly Hans: "Hans";
  readonly Hiujin: "Hiujin";
  readonly Ida: "Ida";
  readonly Ines: "Ines";
  readonly Isabelle: "Isabelle";
  readonly Ivy: "Ivy";
  readonly Jacek: "Jacek";
  readonly Jan: "Jan";
  readonly Jasmine: "Jasmine";
  readonly Jihye: "Jihye";
  readonly Jitka: "Jitka";
  readonly Joanna: "Joanna";
  readonly Joey: "Joey";
  readonly Justin: "Justin";
  readonly Kajal: "Kajal";
  readonly Karl: "Karl";
  readonly Kazuha: "Kazuha";
  readonly Kendra: "Kendra";
  readonly Kevin: "Kevin";
  readonly Kimberly: "Kimberly";
  readonly Laura: "Laura";
  readonly Lea: "Lea";
  readonly Liam: "Liam";
  readonly Lisa: "Lisa";
  readonly Liv: "Liv";
  readonly Lotte: "Lotte";
  readonly Lucia: "Lucia";
  readonly Lupe: "Lupe";
  readonly Mads: "Mads";
  readonly Maja: "Maja";
  readonly Marlene: "Marlene";
  readonly Mathieu: "Mathieu";
  readonly Matthew: "Matthew";
  readonly Maxim: "Maxim";
  readonly Mia: "Mia";
  readonly Miguel: "Miguel";
  readonly Mizuki: "Mizuki";
  readonly Naja: "Naja";
  readonly Niamh: "Niamh";
  readonly Nicole: "Nicole";
  readonly Ola: "Ola";
  readonly Olivia: "Olivia";
  readonly Pedro: "Pedro";
  readonly Penelope: "Penelope";
  readonly Raveena: "Raveena";
  readonly Remi: "Remi";
  readonly Ricardo: "Ricardo";
  readonly Ruben: "Ruben";
  readonly Russell: "Russell";
  readonly Ruth: "Ruth";
  readonly Sabrina: "Sabrina";
  readonly Salli: "Salli";
  readonly Seoyeon: "Seoyeon";
  readonly Sergio: "Sergio";
  readonly Sofie: "Sofie";
  readonly Stephen: "Stephen";
  readonly Suvi: "Suvi";
  readonly Takumi: "Takumi";
  readonly Tatyana: "Tatyana";
  readonly Thiago: "Thiago";
  readonly Tomoko: "Tomoko";
  readonly Vicki: "Vicki";
  readonly Vitoria: "Vitoria";
  readonly Zayd: "Zayd";
  readonly Zeina: "Zeina";
  readonly Zhiyu: "Zhiyu";
};
export type VoiceId = (typeof VoiceId)[keyof typeof VoiceId];
export interface Voice {
  Gender?: Gender | undefined;
  Id?: VoiceId | undefined;
  LanguageCode?: LanguageCode | undefined;
  LanguageName?: string | undefined;
  Name?: string | undefined;
  AdditionalLanguageCodes?: LanguageCode[] | undefined;
  SupportedEngines?: Engine[] | undefined;
}
export interface DescribeVoicesOutput {
  Voices?: Voice[] | undefined;
  NextToken?: string | undefined;
}
export declare class InvalidNextTokenException extends __BaseException {
  readonly name: "InvalidNextTokenException";
  readonly $fault: "client";
  constructor(
    opts: __ExceptionOptionType<InvalidNextTokenException, __BaseException>
  );
}
export declare class EngineNotSupportedException extends __BaseException {
  readonly name: "EngineNotSupportedException";
  readonly $fault: "client";
  constructor(
    opts: __ExceptionOptionType<EngineNotSupportedException, __BaseException>
  );
}
export interface GetLexiconInput {
  Name: string | undefined;
}
export interface Lexicon {
  Content?: string | undefined;
  Name?: string | undefined;
}
export interface LexiconAttributes {
  Alphabet?: string | undefined;
  LanguageCode?: LanguageCode | undefined;
  LastModified?: Date | undefined;
  LexiconArn?: string | undefined;
  LexemesCount?: number | undefined;
  Size?: number | undefined;
}
export interface GetLexiconOutput {
  Lexicon?: Lexicon | undefined;
  LexiconAttributes?: LexiconAttributes | undefined;
}
export interface GetSpeechSynthesisTaskInput {
  TaskId: string | undefined;
}
export declare const OutputFormat: {
  readonly JSON: "json";
  readonly MP3: "mp3";
  readonly OGG_VORBIS: "ogg_vorbis";
  readonly PCM: "pcm";
};
export type OutputFormat = (typeof OutputFormat)[keyof typeof OutputFormat];
export declare const SpeechMarkType: {
  readonly SENTENCE: "sentence";
  readonly SSML: "ssml";
  readonly VISEME: "viseme";
  readonly WORD: "word";
};
export type SpeechMarkType =
  (typeof SpeechMarkType)[keyof typeof SpeechMarkType];
export declare const TaskStatus: {
  readonly COMPLETED: "completed";
  readonly FAILED: "failed";
  readonly IN_PROGRESS: "inProgress";
  readonly SCHEDULED: "scheduled";
};
export type TaskStatus = (typeof TaskStatus)[keyof typeof TaskStatus];
export declare const TextType: {
  readonly SSML: "ssml";
  readonly TEXT: "text";
};
export type TextType = (typeof TextType)[keyof typeof TextType];
export interface SynthesisTask {
  Engine?: Engine | undefined;
  TaskId?: string | undefined;
  TaskStatus?: TaskStatus | undefined;
  TaskStatusReason?: string | undefined;
  OutputUri?: string | undefined;
  CreationTime?: Date | undefined;
  RequestCharacters?: number | undefined;
  SnsTopicArn?: string | undefined;
  LexiconNames?: string[] | undefined;
  OutputFormat?: OutputFormat | undefined;
  SampleRate?: string | undefined;
  SpeechMarkTypes?: SpeechMarkType[] | undefined;
  TextType?: TextType | undefined;
  VoiceId?: VoiceId | undefined;
  LanguageCode?: LanguageCode | undefined;
}
export interface GetSpeechSynthesisTaskOutput {
  SynthesisTask?: SynthesisTask | undefined;
}
export declare class InvalidTaskIdException extends __BaseException {
  readonly name: "InvalidTaskIdException";
  readonly $fault: "client";
  constructor(
    opts: __ExceptionOptionType<InvalidTaskIdException, __BaseException>
  );
}
export declare class SynthesisTaskNotFoundException extends __BaseException {
  readonly name: "SynthesisTaskNotFoundException";
  readonly $fault: "client";
  constructor(
    opts: __ExceptionOptionType<SynthesisTaskNotFoundException, __BaseException>
  );
}
export declare class InvalidLexiconException extends __BaseException {
  readonly name: "InvalidLexiconException";
  readonly $fault: "client";
  constructor(
    opts: __ExceptionOptionType<InvalidLexiconException, __BaseException>
  );
}
export declare class InvalidS3BucketException extends __BaseException {
  readonly name: "InvalidS3BucketException";
  readonly $fault: "client";
  constructor(
    opts: __ExceptionOptionType<InvalidS3BucketException, __BaseException>
  );
}
export declare class InvalidS3KeyException extends __BaseException {
  readonly name: "InvalidS3KeyException";
  readonly $fault: "client";
  constructor(
    opts: __ExceptionOptionType<InvalidS3KeyException, __BaseException>
  );
}
export declare class InvalidSampleRateException extends __BaseException {
  readonly name: "InvalidSampleRateException";
  readonly $fault: "client";
  constructor(
    opts: __ExceptionOptionType<InvalidSampleRateException, __BaseException>
  );
}
export declare class InvalidSnsTopicArnException extends __BaseException {
  readonly name: "InvalidSnsTopicArnException";
  readonly $fault: "client";
  constructor(
    opts: __ExceptionOptionType<InvalidSnsTopicArnException, __BaseException>
  );
}
export declare class InvalidSsmlException extends __BaseException {
  readonly name: "InvalidSsmlException";
  readonly $fault: "client";
  constructor(
    opts: __ExceptionOptionType<InvalidSsmlException, __BaseException>
  );
}
export declare class LanguageNotSupportedException extends __BaseException {
  readonly name: "LanguageNotSupportedException";
  readonly $fault: "client";
  constructor(
    opts: __ExceptionOptionType<LanguageNotSupportedException, __BaseException>
  );
}
export interface LexiconDescription {
  Name?: string | undefined;
  Attributes?: LexiconAttributes | undefined;
}
export declare class LexiconSizeExceededException extends __BaseException {
  readonly name: "LexiconSizeExceededException";
  readonly $fault: "client";
  constructor(
    opts: __ExceptionOptionType<LexiconSizeExceededException, __BaseException>
  );
}
export interface ListLexiconsInput {
  NextToken?: string | undefined;
}
export interface ListLexiconsOutput {
  Lexicons?: LexiconDescription[] | undefined;
  NextToken?: string | undefined;
}
export interface ListSpeechSynthesisTasksInput {
  MaxResults?: number | undefined;
  NextToken?: string | undefined;
  Status?: TaskStatus | undefined;
}
export interface ListSpeechSynthesisTasksOutput {
  NextToken?: string | undefined;
  SynthesisTasks?: SynthesisTask[] | undefined;
}
export declare class MarksNotSupportedForFormatException extends __BaseException {
  readonly name: "MarksNotSupportedForFormatException";
  readonly $fault: "client";
  constructor(
    opts: __ExceptionOptionType<
      MarksNotSupportedForFormatException,
      __BaseException
    >
  );
}
export declare class MaxLexemeLengthExceededException extends __BaseException {
  readonly name: "MaxLexemeLengthExceededException";
  readonly $fault: "client";
  constructor(
    opts: __ExceptionOptionType<
      MaxLexemeLengthExceededException,
      __BaseException
    >
  );
}
export declare class MaxLexiconsNumberExceededException extends __BaseException {
  readonly name: "MaxLexiconsNumberExceededException";
  readonly $fault: "client";
  constructor(
    opts: __ExceptionOptionType<
      MaxLexiconsNumberExceededException,
      __BaseException
    >
  );
}
export interface PutLexiconInput {
  Name: string | undefined;
  Content: string | undefined;
}
export interface PutLexiconOutput {}
export declare class UnsupportedPlsAlphabetException extends __BaseException {
  readonly name: "UnsupportedPlsAlphabetException";
  readonly $fault: "client";
  constructor(
    opts: __ExceptionOptionType<
      UnsupportedPlsAlphabetException,
      __BaseException
    >
  );
}
export declare class UnsupportedPlsLanguageException extends __BaseException {
  readonly name: "UnsupportedPlsLanguageException";
  readonly $fault: "client";
  constructor(
    opts: __ExceptionOptionType<
      UnsupportedPlsLanguageException,
      __BaseException
    >
  );
}
export declare class SsmlMarksNotSupportedForTextTypeException extends __BaseException {
  readonly name: "SsmlMarksNotSupportedForTextTypeException";
  readonly $fault: "client";
  constructor(
    opts: __ExceptionOptionType<
      SsmlMarksNotSupportedForTextTypeException,
      __BaseException
    >
  );
}
export interface StartSpeechSynthesisTaskInput {
  Engine?: Engine | undefined;
  LanguageCode?: LanguageCode | undefined;
  LexiconNames?: string[] | undefined;
  OutputFormat: OutputFormat | undefined;
  OutputS3BucketName: string | undefined;
  OutputS3KeyPrefix?: string | undefined;
  SampleRate?: string | undefined;
  SnsTopicArn?: string | undefined;
  SpeechMarkTypes?: SpeechMarkType[] | undefined;
  Text: string | undefined;
  TextType?: TextType | undefined;
  VoiceId: VoiceId | undefined;
}
export interface StartSpeechSynthesisTaskOutput {
  SynthesisTask?: SynthesisTask | undefined;
}
export declare class TextLengthExceededException extends __BaseException {
  readonly name: "TextLengthExceededException";
  readonly $fault: "client";
  constructor(
    opts: __ExceptionOptionType<TextLengthExceededException, __BaseException>
  );
}
export interface SynthesizeSpeechInput {
  Engine?: Engine | undefined;
  LanguageCode?: LanguageCode | undefined;
  LexiconNames?: string[] | undefined;
  OutputFormat: OutputFormat | undefined;
  SampleRate?: string | undefined;
  SpeechMarkTypes?: SpeechMarkType[] | undefined;
  Text: string | undefined;
  TextType?: TextType | undefined;
  VoiceId: VoiceId | undefined;
}
export interface SynthesizeSpeechOutput {
  AudioStream?: StreamingBlobTypes | undefined;
  ContentType?: string | undefined;
  RequestCharacters?: number | undefined;
}
export declare const LexiconFilterSensitiveLog: (obj: Lexicon) => any;
export declare const GetLexiconOutputFilterSensitiveLog: (
  obj: GetLexiconOutput
) => any;
export declare const PutLexiconInputFilterSensitiveLog: (
  obj: PutLexiconInput
) => any;
export declare const SynthesizeSpeechOutputFilterSensitiveLog: (
  obj: SynthesizeSpeechOutput
) => any;
