import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  StartSpeechSynthesisTaskInput,
  StartSpeechSynthesisTaskOutput,
} from "../models/models_0";
import {
  PollyClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../PollyClient";
export { __MetadataBearer };
export { $Command };
export interface StartSpeechSynthesisTaskCommandInput
  extends StartSpeechSynthesisTaskInput {}
export interface StartSpeechSynthesisTaskCommandOutput
  extends StartSpeechSynthesisTaskOutput,
    __MetadataBearer {}
declare const StartSpeechSynthesisTaskCommand_base: {
  new (
    input: StartSpeechSynthesisTaskCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    StartSpeechSynthesisTaskCommandInput,
    StartSpeechSynthesisTaskCommandOutput,
    PollyClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    input: StartSpeechSynthesisTaskCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    StartSpeechSynthesisTaskCommandInput,
    StartSpeechSynthesisTaskCommandOutput,
    PollyClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class StartSpeechSynthesisTaskCommand extends StartSpeechSynthesisTaskCommand_base {
  protected static __types: {
    api: {
      input: StartSpeechSynthesisTaskInput;
      output: StartSpeechSynthesisTaskOutput;
    };
    sdk: {
      input: StartSpeechSynthesisTaskCommandInput;
      output: StartSpeechSynthesisTaskCommandOutput;
    };
  };
}
