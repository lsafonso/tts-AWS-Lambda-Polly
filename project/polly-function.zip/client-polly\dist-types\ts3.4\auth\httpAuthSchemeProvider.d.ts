import {
  AwsSdkSigV4AuthInputConfig,
  AwsSdkSigV4AuthResolvedConfig,
  AwsSdkSigV4PreviouslyResolved,
} from "@aws-sdk/core";
import {
  HandlerExecutionContext,
  HttpAuthScheme,
  HttpAuthSchemeParameters,
  HttpAuthSchemeParametersProvider,
  HttpAuthSchemeProvider,
  Provider,
} from "@smithy/types";
import { PollyClientResolvedConfig } from "../PollyClient";
export interface PollyHttpAuthSchemeParameters
  extends HttpAuthSchemeParameters {
  region?: string;
}
export interface PollyHttpAuthSchemeParametersProvider
  extends HttpAuthSchemeParametersProvider<
    PollyClientResolvedConfig,
    HandlerExecutionContext,
    PollyHttpAuthSchemeParameters,
    object
  > {}
export declare const defaultPollyHttpAuthSchemeParametersProvider: (
  config: PollyClientResolvedConfig,
  context: HandlerExecutionContext,
  input: object
) => Promise<PollyHttpAuthSchemeParameters>;
export interface PollyHttpAuthSchemeProvider
  extends HttpAuthSchemeProvider<PollyHttpAuthSchemeParameters> {}
export declare const defaultPollyHttpAuthSchemeProvider: PollyHttpAuthSchemeProvider;
export interface HttpAuthSchemeInputConfig extends AwsSdkSigV4AuthInputConfig {
  authSchemePreference?: string[] | Provider<string[]>;
  httpAuthSchemes?: HttpAuthScheme[];
  httpAuthSchemeProvider?: PollyHttpAuthSchemeProvider;
}
export interface HttpAuthSchemeResolvedConfig
  extends AwsSdkSigV4AuthResolvedConfig {
  readonly authSchemePreference: Provider<string[]>;
  readonly httpAuthSchemes: HttpAuthScheme[];
  readonly httpAuthSchemeProvider: PollyHttpAuthSchemeProvider;
}
export declare const resolveHttpAuthSchemeConfig: <T>(
  config: T & HttpAuthSchemeInputConfig & AwsSdkSigV4PreviouslyResolved
) => T & HttpAuthSchemeResolvedConfig;
