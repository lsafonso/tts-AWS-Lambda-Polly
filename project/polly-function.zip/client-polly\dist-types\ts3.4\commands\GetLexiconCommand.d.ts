import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetLexiconInput, GetLexiconOutput } from "../models/models_0";
import {
  PollyClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../PollyClient";
export { __MetadataBearer };
export { $Command };
export interface GetLexiconCommandInput extends GetLexiconInput {}
export interface GetLexiconCommandOutput
  extends GetLexiconOutput,
    __MetadataBearer {}
declare const GetLexiconCommand_base: {
  new (
    input: GetLexiconCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    GetLexiconCommandInput,
    GetLexiconCommandOutput,
    PollyClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    input: GetLexiconCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    GetLexiconCommandInput,
    GetLexiconCommandOutput,
    PollyClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class GetLexiconCommand extends GetLexiconCommand_base {
  protected static __types: {
    api: {
      input: GetLexiconInput;
      output: GetLexiconOutput;
    };
    sdk: {
      input: GetLexiconCommandInput;
      output: GetLexiconCommandOutput;
    };
  };
}
