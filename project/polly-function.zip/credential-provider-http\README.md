# @aws-sdk/credential-provider-http

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/credential-provider-http/latest.svg)](https://www.npmjs.com/package/@aws-sdk/credential-provider-http)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/credential-provider-http.svg)](https://www.npmjs.com/package/@aws-sdk/credential-provider-http)

> An internal transitively required package.

## Usage

See https://www.npmjs.com/package/@aws-sdk/credential-providers
