/**
 * @internal
 *
 * Used for awsQueryCompatibility trait.
 */
export declare const _toStr: (val: unknown) => string | undefined;
/**
 * @internal
 *
 * Used for awsQueryCompatibility trait.
 */
export declare const _toBool: (val: unknown) => boolean | undefined;
/**
 * @internal
 *
 * Used for awsQueryCompatibility trait.
 */
export declare const _toNum: (val: unknown) => number | undefined;
