import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DeleteLexiconInput, DeleteLexiconOutput } from "../models/models_0";
import {
  PollyClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../PollyClient";
export { __MetadataBearer };
export { $Command };
export interface DeleteLexiconCommandInput extends DeleteLexiconInput {}
export interface DeleteLexiconCommandOutput
  extends DeleteLexiconOutput,
    __MetadataBearer {}
declare const DeleteLexiconCommand_base: {
  new (
    input: DeleteLexiconCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DeleteLexiconCommandInput,
    DeleteLexiconCommandOutput,
    PollyClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    input: DeleteLexiconCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DeleteLexiconCommandInput,
    DeleteLexiconCommandOutput,
    PollyClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DeleteLexiconCommand extends DeleteLexiconCommand_base {
  protected static __types: {
    api: {
      input: DeleteLexiconInput;
      output: {};
    };
    sdk: {
      input: DeleteLexiconCommandInput;
      output: DeleteLexiconCommandOutput;
    };
  };
}
