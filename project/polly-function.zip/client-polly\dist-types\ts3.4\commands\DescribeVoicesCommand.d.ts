import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DescribeVoicesInput, DescribeVoicesOutput } from "../models/models_0";
import {
  PollyClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../PollyClient";
export { __MetadataBearer };
export { $Command };
export interface DescribeVoicesCommandInput extends DescribeVoicesInput {}
export interface DescribeVoicesCommandOutput
  extends DescribeVoicesOutput,
    __MetadataBearer {}
declare const DescribeVoicesCommand_base: {
  new (
    input: DescribeVoicesCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DescribeVoicesCommandInput,
    DescribeVoicesCommandOutput,
    PollyClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [DescribeVoicesCommandInput]
  ): import("@smithy/smithy-client").CommandImpl<
    DescribeVoicesCommandInput,
    DescribeVoicesCommandOutput,
    PollyClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DescribeVoicesCommand extends DescribeVoicesCommand_base {
  protected static __types: {
    api: {
      input: DescribeVoicesInput;
      output: DescribeVoicesOutput;
    };
    sdk: {
      input: DescribeVoicesCommandInput;
      output: DescribeVoicesCommandOutput;
    };
  };
}
